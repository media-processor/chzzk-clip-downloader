function u(e, i) {
  i = i || "info";
  let r = document.getElementById("chzzk-toast-container");
  r || (r = document.createElement("div"), r.id = "chzzk-toast-container", r.style.cssText = "position: fixed; top: 20px; right: 20px; z-index: 999999; display: flex; flex-direction: column; gap: 10px; pointer-events: none;", document.body.appendChild(r));
  const n = document.createElement("div");
  n.style.cssText = 'background: rgba(0, 0, 0, 0.85); color: white; padding: 12px 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; font-size: 14px; min-width: 250px; max-width: 400px; pointer-events: auto; opacity: 0; transform: translateX(100%); transition: all 0.3s ease;';
  const t = { success: "#10b981", error: "#ef4444", info: "#3b82f6", warning: "#f59e0b" }, o = t[i] || t.info;
  n.style.borderLeft = "4px solid " + o;
  const s = { success: "✓", error: "✕", info: "ℹ", warning: "⚠" }, c = s[i] || s.info;
  n.innerHTML = '<div style="display: flex; align-items: center; gap: 10px;"><span style="font-size: 18px; font-weight: bold; color: ' + o + ';">' + c + '</span><span style="flex: 1;">' + e + "</span></div>", r.appendChild(n), setTimeout(function() {
    n.style.opacity = "1", n.style.transform = "translateX(0)";
  }, 10), setTimeout(function() {
    n.style.opacity = "0", n.style.transform = "translateX(100%)", setTimeout(function() {
      n.parentNode && n.parentNode.removeChild(n), r.children.length === 0 && r.parentNode && r.parentNode.removeChild(r);
    }, 300);
  }, 3e3);
}
new PerformanceObserver(function(e) {
  for (const i of e.getEntries()) if (i.entryType === "resource") {
    const r = i.name;
    r.indexOf(".ts") === -1 && r.indexOf("_chunklist.m3u8") === -1 || g(r);
  }
}).observe({ entryTypes: ["resource"] });
if (performance.getEntriesByType("resource").forEach(function(e) {
  const i = e.name;
  i.indexOf(".ts") === -1 && i.indexOf("_chunklist.m3u8") === -1 || g(i);
}), typeof window < "u") {
  const e = window.fetch, i = XMLHttpRequest.prototype.open, r = XMLHttpRequest.prototype.send;
  window._originalFetch = e, window.fetch = function(...n) {
    const t = n[0];
    return typeof t == "string" && g(t), e.apply(this, n);
  }, XMLHttpRequest.prototype.open = function(n, t, ...o) {
    return this._url = t, i.apply(this, [n, t, ...o]);
  }, XMLHttpRequest.prototype.send = function(...n) {
    return this._url && g(this._url), r.apply(this, n);
  };
}
let l = !1, f = !1, w = !1, p = /* @__PURE__ */ new Set(), m = null, y = !0, _ = !0;
const h = '<svg focusable="false" xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none" aria-hidden="true" class="pzp-ui-icon__svg"><circle cx="18" cy="18" r="8" stroke="white" stroke-width="2"/><circle cx="18" cy="18" r="4" fill="white" opacity="0.4"/></svg>', T = '<svg focusable="false" xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none" aria-hidden="true" class="pzp-ui-icon__svg"><circle cx="18" cy="18" r="8" stroke="white" stroke-width="2"/><circle cx="18" cy="18" r="5" fill="#FF0000"><animate attributeName="opacity" values="1;0.4;1" dur="1s" repeatCount="indefinite" /></circle></svg>';
function v(e) {
  if (!Number.isFinite(e) || e < 0) return "00:00";
  const i = Math.floor(e);
  return String(Math.floor(i / 60)).padStart(2, "0") + ":" + String(i % 60).padStart(2, "0");
}
async function x() {
  if (!chrome.runtime?.id) throw new Error("확장 프로그램이 업데이트되었습니다. 페이지를 새로고침해주세요.");
  const e = document.querySelector("video.webplayer-internal-video");
  if (!e) throw new Error("플레이어 비디오를 찾을 수 없습니다.");
  if (e.readyState < HTMLMediaElement.HAVE_CURRENT_DATA) throw new Error("아직 캡처 가능한 프레임이 없습니다. 잠시 후 다시 시도해주세요.");
  const i = (function(t) {
    if (!t.videoWidth || !t.videoHeight) throw new Error("비디오 메타데이터가 준비되지 않았습니다.");
    const o = Math.min(t.videoWidth, 1920), s = Math.round(t.videoHeight * o / t.videoWidth), c = document.createElement("canvas");
    c.width = o, c.height = s;
    const a = c.getContext("2d");
    if (!a) throw new Error("Canvas 컨텍스트를 생성할 수 없습니다.");
    a.imageSmoothingEnabled = !0, a.imageSmoothingQuality = "high", a.drawImage(t, 0, 0, o, s);
    const d = c.toDataURL("image/png");
    return d.length > 15e5 ? c.toDataURL("image/jpeg", 0.92) : d;
  })(e), r = { id: "shot-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8), imageData: i, timestamp: Date.now(), currentTime: e.currentTime, formattedCurrentTime: v(e.currentTime), pageUrl: location.href, pageTitle: document.title }, n = await chrome.runtime.sendMessage({ type: "SAVE_SCREENSHOT", screenshot: r });
  if (!n?.success) throw new Error(n?.error || "스크린샷 저장에 실패했습니다.");
}
function b() {
  const e = document.querySelector(".pzp-pc__bottom-buttons-right"), i = document.querySelector(".pzp-pc__video-record-button"), r = document.querySelector(".pzp-pc__video-screenshot-button");
  if (y || i?.remove(), _ || r?.remove(), e) {
    let n = i;
    if (y && !n && (n = (function() {
      const t = document.createElement("button");
      t.className = "pzp-button pzp-pc-setting-button pzp-pc__setting-button pzp-pc__video-record-button", t.setAttribute("aria-label", "녹화 시작");
      const o = document.createElement("span");
      o.className = "pzp-button__tooltip pzp-button__tooltip--top", o.textContent = "녹화 시작";
      const s = document.createElement("span");
      return s.className = "pzp-ui-icon pzp-setting-button__icon", s.innerHTML = h, t.appendChild(o), t.appendChild(s), chrome.runtime?.id && chrome.storage?.local && chrome.storage.local.get(["isRecording"], function(c) {
        c.isRecording === !0 && (l = !0, s.innerHTML = T, o.textContent = "녹화 중지", t.setAttribute("aria-label", "녹화 중"));
      }), t.addEventListener("click", function() {
        if (chrome.runtime?.id) {
          if (f) u("변환 중입니다. 잠시만 기다려주세요.", "warning");
          else if (!w) if (l) {
            if (p.size === 0) return u("녹화된 데이터가 없습니다. 조금 더 녹화한 후 중지해주세요.", "warning"), void chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "warning", message: "녹화된 데이터가 없습니다" }).catch(function() {
            });
            if (p.size < 4) return u("녹화 시간이 너무 짧습니다. 최소 2초 이상 녹화해주세요.", "warning"), void chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "warning", message: "녹화 시간이 너무 짧습니다" }).catch(function() {
            });
            l = !1, f = !0, t.disabled = !0, s.innerHTML = h, o.textContent = "변환 중...", t.setAttribute("aria-label", "변환 중"), chrome.runtime.sendMessage({ type: "STOP_LIVE_RECORDING" }).catch(function() {
            }), u("라이브 녹화 종료 중...", "info"), chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "info", message: "라이브 녹화 종료 중..." }).catch(function() {
            });
          } else {
            p.clear(), m = null, l = !0, w = !0, s.innerHTML = T, o.textContent = "5초동안 중단불가", t.setAttribute("aria-label", "녹화 중"), chrome.runtime.sendMessage({ type: "START_LIVE_RECORDING" }).catch(function() {
            }), u("라이브 녹화 시작", "success"), chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "success", message: "라이브 녹화 시작" }).catch(function() {
            });
            let c = 5;
            const a = setInterval(function() {
              c--, c > 0 ? o.textContent = c + "초동안 중단불가" : (clearInterval(a), w = !1, o.textContent = "녹화 중단", t.setAttribute("aria-label", "녹화 중단"));
            }, 1e3);
          }
        } else u("확장 프로그램이 업데이트되었습니다. 페이지를 새로고침해주세요.", "error");
      }), t;
    })(), e.insertBefore(n, e.firstChild)), _ && !r) {
      const t = (function() {
        const o = document.createElement("button");
        o.className = "pzp-button pzp-pc-setting-button pzp-pc__setting-button pzp-pc__video-screenshot-button", o.setAttribute("aria-label", "스크린샷 캡처");
        const s = document.createElement("span");
        s.className = "pzp-button__tooltip pzp-button__tooltip--top", s.textContent = "스크린샷 캡처";
        const c = document.createElement("span");
        return c.className = "pzp-ui-icon pzp-setting-button__icon", c.innerHTML = '<svg focusable="false" xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none" aria-hidden="true" class="pzp-ui-icon__svg"><rect x="8" y="11" width="20" height="14" rx="2" stroke="white" stroke-width="2"/><rect x="13" y="8" width="6" height="3" rx="1" fill="white" opacity="0.8"/><circle cx="18" cy="18" r="4" stroke="white" stroke-width="2"/></svg>', o.appendChild(s), o.appendChild(c), o.addEventListener("click", function() {
          x().then(function() {
            u("스크린샷을 갤러리에 저장했습니다.", "success"), chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "success", message: "스크린샷이 갤러리에 저장되었습니다" }).catch(function() {
            });
          }).catch(function(a) {
            console.error("Failed to capture screenshot:", a), u(a.message, "error");
          });
        }), o;
      })();
      n ? e.insertBefore(t, n) : e.insertBefore(t, e.firstChild);
    }
  }
}
function g(e) {
  l && e.indexOf("_chunklist.m3u8") !== -1 && (async function(i) {
    if (i) try {
      const r = await window._originalFetch(i), n = await r.text(), t = i.split("/").slice(0, -1).join("/") + "/", o = n.split(`
`);
      for (let s = 0; s < o.length; s++) {
        let c = o[s].trim();
        if (c.indexOf('#EXT-X-MAP:URI="') === 0) {
          const a = c.match(/URI="([^"]+)"/);
          if (a) {
            const d = new URL(a[1], t).href;
            m !== d && (m = d, chrome.runtime?.id && chrome.runtime.sendMessage({ type: "SET_INIT_SEGMENT", url: m }).catch(function() {
            }));
          }
        } else if (c && c.indexOf("#") !== 0 && (c.indexOf(".m4v") !== -1 || c.indexOf(".ts") !== -1)) {
          const a = new URL(c, t).href;
          p.has(a) || (p.add(a), chrome.runtime?.id && chrome.runtime.sendMessage({ type: "ADD_RECORDING_SEGMENT", url: a }).catch(function() {
          }));
        }
      }
    } catch (r) {
      console.error(r);
    }
  })(e), (function(i) {
    if (i.indexOf(".ts") === -1) return;
    const r = i.indexOf(".pstatic.net") !== -1, n = i.indexOf("glive-clip") !== -1, t = i.indexOf("/hls/") !== -1;
    if (r && n && t) {
      const o = location.href, s = (function(c) {
        if (!c) return null;
        const a = c.match(/\/clips\/([A-Za-z0-9_-]+)/);
        return a ? a[1] : null;
      })(o);
      if (!chrome.runtime?.id) return;
      chrome.runtime.sendMessage({ type: "HLS_SEGMENT_DETECTED", url: i, clipId: s, pageUrl: o }).catch(function() {
      });
    }
  })(e);
}
chrome.runtime.onMessage.addListener(function(e, i, r) {
  if (e.type === "SHOW_CONTENT_TOAST") u(e.message, e.toastType), r({ success: !0 });
  else if (e.type === "UPDATE_RECORD_BUTTON_SETTING") y = e.enabled, b(), r({ success: !0 });
  else if (e.type === "UPDATE_SCREENSHOT_BUTTON_SETTING") _ = e.enabled, b(), r({ success: !0 });
  else if (e.type === "RECORDING_COMPLETE" || e.type === "RECORDING_FAILED") {
    l = !1, f = !1;
    const n = document.querySelector(".pzp-pc__video-record-button");
    if (n) {
      const t = n.querySelector(".pzp-ui-icon"), o = n.querySelector(".pzp-button__tooltip");
      t && (t.innerHTML = h), o && (o.textContent = "녹화 시작"), n.disabled = !1, n.setAttribute("aria-label", "녹화 시작");
    }
    chrome.storage?.local && chrome.storage.local.remove("isRecording"), r({ success: !0 });
  }
  return !0;
}), window.addEventListener("beforeunload", function() {
  if (l) try {
    chrome.runtime.sendMessage({ type: "PAGE_UNLOADING_DURING_RECORDING" });
  } catch {
  }
}), window.addEventListener("unload", function() {
  if (l) try {
    chrome.runtime.sendMessage({ type: "PAGE_UNLOADING_DURING_RECORDING" });
  } catch {
  }
});
const E = new MutationObserver(function(e) {
  if (l) {
    for (const i of e) if (i.type === "childList") {
      for (const r of i.addedNodes) if (r.nodeType === Node.ELEMENT_NODE) {
        const n = r;
        if (n.tagName === "DIV" && n.classList.contains("pip_mode")) {
          l = !1, f = !0;
          const t = document.querySelector(".pzp-pc__video-record-button");
          if (t) {
            const o = t.querySelector(".pzp-ui-icon"), s = t.querySelector(".pzp-button__tooltip");
            o && (o.innerHTML = h), s && (s.textContent = "변환 중..."), t.disabled = !0, t.setAttribute("aria-label", "변환 중");
          }
          return chrome.runtime.sendMessage({ type: "STOP_LIVE_RECORDING" }).catch(function() {
          }), u("PIP 모드 감지: 라이브 녹화 종료 중...", "info"), void chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "info", message: "PIP 모드 감지: 라이브 녹화 종료 중..." }).catch(function() {
          });
        }
        if (n.querySelector("div.pip_mode")) {
          l = !1, f = !0;
          const t = document.querySelector(".pzp-pc__video-record-button");
          if (t) {
            const o = t.querySelector(".pzp-ui-icon"), s = t.querySelector(".pzp-button__tooltip");
            o && (o.innerHTML = h), s && (s.textContent = "변환 중..."), t.disabled = !0, t.setAttribute("aria-label", "변환 중");
          }
          return chrome.runtime.sendMessage({ type: "STOP_LIVE_RECORDING" }).catch(function() {
          }), u("PIP 모드 감지: 라이브 녹화 종료 중...", "info"), void chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "info", message: "PIP 모드 감지: 라이브 녹화 종료 중..." }).catch(function() {
          });
        }
      }
    }
  }
});
document.body ? E.observe(document.body, { childList: !0, subtree: !0 }) : document.addEventListener("DOMContentLoaded", function() {
  E.observe(document.body, { childList: !0, subtree: !0 });
}), Promise.all([(async function() {
  try {
    const e = await chrome.storage.local.get(["recordButtonEnabled"]);
    e.recordButtonEnabled !== void 0 && (y = e.recordButtonEnabled);
  } catch (e) {
    console.error("Failed to load record button setting:", e);
  }
})(), (async function() {
  try {
    const e = await chrome.storage.local.get(["screenshotButtonEnabled"]);
    e.screenshotButtonEnabled !== void 0 && (_ = e.screenshotButtonEnabled);
  } catch (e) {
    console.error("Failed to load screenshot button setting:", e);
  }
})()]).then(function() {
  setInterval(b, 1e3), b();
});
