const b = /* @__PURE__ */ new Map();
let H = null, v = null;
const z = "galleryScreenshots", P = "https://chzzk.naver.com", K = ["ba.uuid", "BUC", "NAC", "NACT", "NID_AUT", "nid_inf", "NID_SES", "NNB"], F = /* @__PURE__ */ new Set();
function V(t) {
  if (!t) return null;
  const r = t.match(/\/clips\/([A-Za-z0-9_-]+)/);
  return r ? r[1] : null;
}
async function Y(t) {
  const r = { clipTitle: null, ownerChannelName: null, ownerChannelImageUrl: null };
  try {
    const n = await (async function() {
      if (!chrome.cookies || typeof chrome.cookies.get != "function") return {};
      const c = await Promise.all(K.map(async function(l) {
        const s = await chrome.cookies.get({ url: P, name: l });
        return [l, s?.value || null];
      }));
      return Object.fromEntries(c);
    })();
    if (!n || !Object.values(n).some((c) => c)) return r;
    const e = { accept: "application/json, text/plain, */*", "accept-language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7", "cache-control": "no-cache", "front-client-platform-type": "PC", "front-client-product-type": "web", "if-modified-since": "Mon, 26 Jul 1997 05:00:00 GMT", origin: P, pragma: "no-cache", referer: `${P}/clips/${t}`, dnt: "1" };
    n["ba.uuid"] && (e.deviceid = n["ba.uuid"]);
    const a = new AbortController(), i = setTimeout(() => a.abort(), 1e4);
    try {
      const c = await fetch(`https://api.chzzk.naver.com/service/v1/clips/${t}/detail?optionalProperties=COMMENT&optionalProperties=PRIVATE_USER_BLOCK&optionalProperties=PENALTY&optionalProperties=MAKER_CHANNEL&optionalProperties=OWNER_CHANNEL`, { method: "GET", headers: e, credentials: "include", cache: "no-store", signal: a.signal });
      if (clearTimeout(i), !c.ok) return c.status, r;
      let l;
      try {
        l = await c.json();
      } catch {
        return r;
      }
      if (!l || typeof l != "object") return r;
      if (l.code && l.code !== 200) return l.code, r;
      const s = l.content;
      if (!s || typeof s != "object") return r;
      const m = s.clipTitle, u = s.optionalProperty, d = u?.ownerChannel, f = { clipTitle: null, ownerChannelName: null, ownerChannelImageUrl: null };
      if (typeof m == "string" && m.trim().length > 0 && (f.clipTitle = m.trim()), d && typeof d == "object") {
        const g = d.channelName;
        typeof g == "string" && g.trim().length > 0 && (f.ownerChannelName = g.trim());
        const h = d.channelImageUrl;
        typeof h == "string" && h.length > 0 && h.match(/^https?:\/\//) && (f.ownerChannelImageUrl = h);
      }
      return f;
    } catch (c) {
      return clearTimeout(i), c instanceof TypeError && c.message === "Failed to fetch" || c instanceof Error && c.name, r;
    }
  } catch {
    return r;
  }
}
async function W(t) {
  const r = b.get(t);
  if (r && r.clipId && !r.clipTitle && !F.has(t)) {
    F.add(t), r.titleLoading = !0, b.set(t, r);
    try {
      const n = await Y(r.clipId), e = b.get(t);
      if (!e) return;
      e.titleLoading = !1, n.clipTitle ? (e.clipTitle = n.clipTitle, e.titleFailed = !1) : e.titleFailed = !0, n.ownerChannelName && (e.ownerChannelName = n.ownerChannelName), n.ownerChannelImageUrl && (e.ownerChannelImageUrl = n.ownerChannelImageUrl), b.set(t, e);
    } finally {
      F.delete(t);
    }
  }
}
function j(t, r = {}) {
  const n = t.match(/(.*\/)([^/]+)\.ts(\?.*)?$/);
  if (!n) return;
  const e = n[1], a = n[2], i = /^\d+$/.test(a), c = /^[a-f0-9\-]+-\d+$/.test(a);
  if (!i && !c || (H !== e && (H = e, v !== null && v !== e && (v = null)), v === e)) return;
  const l = (function(s) {
    for (const m of s) {
      if (!m) continue;
      const u = V(m);
      if (u) return u;
    }
    return null;
  })([r.clipId, r.pageUrl, r.documentUrl, r.initiator, r.tabUrl]);
  if (b.has(e)) {
    if (l) {
      const s = b.get(e);
      s && !s.clipId && (s.clipId = l, b.set(e, s)), W(e).catch(function() {
      });
    }
  } else {
    const s = { firstSegmentUrl: t, baseUrl: e, timestamp: Date.now(), downloaded: !1, thumbnailData: null, clipId: l, clipTitle: null, titleLoading: !1, titleFailed: !1 };
    b.set(e, s), W(e).catch(function() {
    }), chrome.runtime.sendMessage({ type: "NEW_CLIP_DETECTED", clip: s }).catch(function() {
    });
  }
}
let N = null;
async function G(t) {
  const r = new Blob([t], { type: "application/octet-binary" });
  return new Promise(function(n, e) {
    const a = new FileReader();
    a.onloadend = function() {
      const i = a.result;
      if (typeof i == "string") {
        const c = i.split(",")[1];
        n(c);
      } else e(new Error("Failed to convert to base64"));
    }, a.onerror = e, a.readAsDataURL(r);
  });
}
async function C(t, r) {
  return new Promise(function(n, e) {
    const a = indexedDB.open(t);
    a.onerror = function() {
      e(a.error);
    }, a.onupgradeneeded = function() {
      const i = a.result;
      i.objectStoreNames.contains(r) || i.createObjectStore(r);
    }, a.onsuccess = function() {
      const i = a.result;
      if (i.objectStoreNames.contains(r)) return void n(i);
      const c = i.version + 1;
      i.close();
      const l = indexedDB.open(t, c);
      l.onerror = function() {
        e(l.error);
      }, l.onupgradeneeded = function() {
        const s = l.result;
        s.objectStoreNames.contains(r) || s.createObjectStore(r);
      }, l.onsuccess = function() {
        n(l.result);
      };
    };
  });
}
function B(t) {
  if (t === 0) return "0 Bytes";
  const r = Math.floor(Math.log(t) / Math.log(1024));
  return parseFloat((t / Math.pow(1024, r)).toFixed(2)) + " " + ["Bytes", "KB", "MB", "GB", "TB"][r];
}
chrome.action.onClicked.addListener(function() {
  (async function() {
    if (N !== null) try {
      return await chrome.windows.get(N), void await chrome.windows.update(N, { focused: !0 });
    } catch {
      N = null;
    }
    N = (await chrome.windows.create({ url: chrome.runtime.getURL("index.html"), type: "popup", width: 600, height: 650, focused: !0 })).id ?? null, chrome.windows.onRemoved.addListener(function(r) {
      r === N && (N = null);
    });
  })();
}), chrome.webRequest.onBeforeRequest.addListener(function(t) {
  const r = t.url;
  if (r.indexOf(".ts") === -1) return;
  const n = r.indexOf(".pstatic.net") !== -1, e = r.indexOf("glive-clip") !== -1, a = r.indexOf("/hls/") !== -1;
  n && e && a && j(r, { documentUrl: t.documentUrl || null, initiator: t.initiator || null });
}, { urls: ["https://*.pstatic.net/*"] }), chrome.tabs.onRemoved.addListener(function(t) {
  o.active && o.tabId === t && _();
}), chrome.tabs.onUpdated.addListener(function(t, r, n) {
  o.active && o.tabId === t && r.url && (r.url, _());
});
let o = { active: !1, channelId: null, opfsWritable: null, opfsFileHandle: null, initSegmentProcessed: !1, initSegmentData: null, tabId: null, liveChannelId: null, lastSegmentTime: 0, inactivityTimer: null, segmentDuration: 1, recordingStartTime: 0, partNumber: 1 };
async function I() {
  const t = (await chrome.storage.local.get([z]))[z];
  return Array.isArray(t) ? t : [];
}
async function L(t = !0) {
  return await (await navigator.storage.getDirectory()).getDirectoryHandle("screenshots", { create: t });
}
async function q(t) {
  const r = await fetch(t);
  if (!r.ok) throw new Error("Failed to decode screenshot image data");
  return await r.blob();
}
async function X(t) {
  const r = await t.arrayBuffer(), n = await G(r);
  return `data:${t.type || "application/octet-stream"};base64,${n}`;
}
async function x(t, r, n) {
  const e = await L(!0), a = /* @__PURE__ */ (function(s) {
    return s === "image/jpeg" ? "jpg" : s === "image/webp" ? "webp" : "png";
  })(n || r.type), i = `${t}.${a}`, c = await e.getFileHandle(i, { create: !0 }), l = await c.createWritable();
  return await l.write(r), await l.close(), i;
}
async function J(t) {
  if (!t) return null;
  try {
    return await (await (await L(!1)).getFileHandle(t)).getFile();
  } catch {
    return null;
  }
}
async function R(t) {
  if (t) try {
    await (await L(!1)).removeEntry(t);
  } catch {
  }
}
async function O(t) {
  let r = !1;
  const n = [];
  for (const e of t) if (e.fileName) n.push(e);
  else if (e.imageData) try {
    const a = await q(e.imageData), i = await x(e.id, a, a.type);
    n.push({ ...e, fileName: i, mimeType: a.type || "image/png", size: a.size, imageData: void 0 }), r = !0;
  } catch {
    e.id, r = !0;
  }
  else r = !0;
  return r && await A(n), n;
}
async function M(t) {
  const r = [];
  let n = !1;
  for (const e of t) {
    const a = await J(e.fileName);
    if (!a) {
      n = !0;
      continue;
    }
    const i = await X(a);
    r.push({ ...e, imageData: i });
  }
  if (n) {
    const e = new Set(r.map((i) => i.id)), a = t.filter((i) => e.has(i.id));
    await A(a);
  }
  return r;
}
async function A(t) {
  await chrome.storage.local.set({ [z]: t });
}
function Q(t) {
  const r = String(t?.message || t || "");
  return r.includes("QUOTA_BYTES") || r.includes("quota");
}
async function k() {
  try {
    const t = await L(!1);
    let r = 0, n = 0;
    for await (const e of t.values())
      e.kind === "file" && (r += (await e.getFile()).size, n += 1);
    return { usageBytes: r, fileCount: n };
  } catch {
    return { usageBytes: 0, fileCount: 0 };
  }
}
function $() {
  o.inactivityTimer && clearTimeout(o.inactivityTimer), o.inactivityTimer = setTimeout(function() {
    o.active && Date.now() - o.lastSegmentTime >= 3e4 && _();
  }, 3e4);
}
async function _(t = !1) {
  try {
    if (!o.active) return;
    if (!o.opfsWritable || !o.opfsFileHandle) return void console.error("No recording data to finalize");
    t || (o.active = !1);
    const r = o.partNumber, n = o.opfsWritable, e = o.opfsFileHandle;
    o.opfsWritable = null, o.opfsFileHandle = null, await n.close();
    const a = await e.getFile(), i = await a.arrayBuffer();
    i.byteLength;
    let c = i;
    try {
      await U();
      const u = "chzzk-temp-storage", d = "video-data", f = "final-recording-" + Date.now();
      {
        const h = await C(u, d);
        await new Promise(function(y, E) {
          const p = h.transaction([d], "readwrite");
          p.objectStore(d).put(i, f), p.oncomplete = function() {
            h.close(), y();
          }, p.onerror = function() {
            h.close(), E(p.error);
          };
        });
      }
      const g = await chrome.runtime.sendMessage({ type: "RESET_MP4_TIMESTAMPS", dbName: u, storeName: d, dataKey: f });
      if (g && g.success && g.resultKey) c = await new Promise(async function(h, y) {
        try {
          const E = await C(u, d), p = E.transaction([d], "readonly"), T = p.objectStore(d).get(g.resultKey);
          T.onsuccess = function() {
            const S = T.result, w = E.transaction([d], "readwrite"), D = w.objectStore(d);
            D.delete(f), D.delete(g.resultKey), w.oncomplete = function() {
              E.close(), h(S);
            }, w.onerror = function() {
              E.close(), y(w.error);
            };
          }, T.onerror = function() {
            E.close(), y(T.error);
          };
        } catch (E) {
          y(E);
        }
      }), c.byteLength;
      else {
        const h = await C(u, d), y = h.transaction([d], "readwrite");
        y.objectStore(d).delete(f), y.oncomplete = function() {
          h.close();
        };
      }
    } catch (u) {
      console.error("Failed to reset timestamps, using original data:", u);
    }
    const l = o.liveChannelId, s = "chzzk-recording/" + l + "/" + (r + ".mp4");
    (c.byteLength / 1048576).toFixed(2);
    try {
      const u = new Blob([c], { type: "video/mp4" }), d = "chzzk-temp-storage", f = "video-data", g = "download-blob-" + Date.now();
      {
        const p = await C(d, f);
        await new Promise(function(T, S) {
          const w = p.transaction([f], "readwrite"), D = w.objectStore(f).put(u, g);
          D.onsuccess = function() {
            T();
          }, D.onerror = function() {
            S(D.error);
          }, w.oncomplete = function() {
            p.close();
          }, w.onerror = function() {
            p.close();
          };
        });
      }
      await U();
      const h = await chrome.runtime.sendMessage({ type: "DOWNLOAD_BLOB", blobKey: g, filename: s });
      if (!h || !h.success || !h.blobUrl) throw new Error(h?.error || "Failed to create blob URL");
      await chrome.downloads.download({ url: h.blobUrl, filename: s, saveAs: !1 });
      const y = await C(d, f), E = y.transaction([f], "readwrite");
      E.objectStore(f).delete(g), E.oncomplete = function() {
        y.close();
      }, c.byteLength, setTimeout(async function() {
        try {
          await U();
          const p = await chrome.runtime.sendMessage({ type: "CLEANUP_INDEXEDDB", keepKeys: [] });
          p.success ? p.deletedCount : console.error("IndexedDB cleanup failed:", p.error);
        } catch (p) {
          console.error("Failed to cleanup IndexedDB:", p);
        }
      }, 5e3);
    } catch (u) {
      throw console.error("Download failed:", u), u;
    }
    t || (chrome.runtime.sendMessage({ type: "DISPLAY_TOAST", toastType: "success", message: "라이브 녹화 완료!" }).catch(function() {
    }), chrome.tabs.query({ active: !0 }).then(function(u) {
      u && u.length > 0 && u[0].id && (chrome.tabs.sendMessage(u[0].id, { type: "SHOW_CONTENT_TOAST", toastType: "success", message: "라이브 녹화 완료!" }).catch(function() {
      }), chrome.tabs.sendMessage(u[0].id, { type: "RECORDING_COMPLETE" }).catch(function() {
      }));
    }).catch(function() {
    })), o.channelId;
    const m = o.opfsFileName;
    if (t || (o.inactivityTimer && clearTimeout(o.inactivityTimer), o = { active: !1, channelId: null, opfsWritable: null, opfsFileHandle: null, initSegmentProcessed: !1, initSegmentData: null, opfsFileName: null, tabId: null, liveChannelId: null, lastSegmentTime: 0, inactivityTimer: null, segmentDuration: 1, recordingStartTime: 0, partNumber: 1 }, chrome.tabs.query({}, function(u) {
      u.forEach(function(d) {
        d.id && chrome.tabs.sendMessage(d.id, { type: "RECORDING_COMPLETE" }).catch(function() {
        });
      });
    }), await chrome.storage.local.remove("isRecording")), m) try {
      await (await (await navigator.storage.getDirectory()).getDirectoryHandle("recordings", { create: !1 })).removeEntry(m);
    } catch {
    }
  } catch (r) {
    console.error("Finalization error:", r), o.inactivityTimer && clearTimeout(o.inactivityTimer);
    try {
      await chrome.storage.local.remove("isRecording");
    } catch {
    }
    o = { active: !1, channelId: null, opfsWritable: null, liveChannelId: null, inactivityTimer: null, segmentDuration: 1, recordingStartTime: 0, partNumber: 1 }, chrome.tabs.query({ active: !0 }).then(function(n) {
      n && n.length > 0 && n[0].id && (chrome.tabs.sendMessage(n[0].id, { type: "SHOW_CONTENT_TOAST", toastType: "error", message: "녹화 처리 중 오류가 발생했습니다" }).catch(function() {
      }), chrome.tabs.sendMessage(n[0].id, { type: "RECORDING_FAILED" }).catch(function() {
      }));
    }).catch(function() {
    });
  }
}
async function U() {
  await chrome.offscreen.hasDocument() || await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["BLOBS"], justification: "WASM processing for video timestamp reset" });
}
chrome.runtime.onMessage.addListener(function(t, r, n) {
  if (t.type === "UPDATE_RECORD_BUTTON_SETTING") return chrome.tabs.query({ url: "*://chzzk.naver.com/*" }, function(e) {
    e.forEach(function(a) {
      a.id && chrome.tabs.sendMessage(a.id, { type: "UPDATE_RECORD_BUTTON_SETTING", enabled: t.enabled }).catch(function() {
      });
    });
  }), n({ success: !0 }), !0;
  if (t.type === "UPDATE_SCREENSHOT_BUTTON_SETTING") return chrome.tabs.query({ url: "*://chzzk.naver.com/*" }, function(e) {
    e.forEach(function(a) {
      a.id && chrome.tabs.sendMessage(a.id, { type: "UPDATE_SCREENSHOT_BUTTON_SETTING", enabled: t.enabled }).catch(function() {
      });
    });
  }), n({ success: !0 }), !0;
  if (t.type === "START_LIVE_RECORDING") return (async function() {
    const e = await (async function() {
      try {
        const T = await navigator.storage.estimate(), S = T.quota - T.usage;
        return { available: S, quota: T.quota, enoughSpace: S >= 5368709120 };
      } catch (T) {
        return console.error("Failed to estimate storage:", T), { available: 0, quota: 0, enoughSpace: !0 };
      }
    })();
    if (e.available, !e.enoughSpace) {
      const T = B(e.available), S = B(e.quota);
      try {
        await chrome.runtime.sendMessage({ type: "STORAGE_WARNING", available: T, quota: S });
      } catch {
      }
      try {
        const w = await chrome.tabs.query({ active: !0 });
        w && w.length > 0 && w[0].id && await chrome.tabs.sendMessage(w[0].id, { type: "SHOW_CONTENT_TOAST", toastType: "warning", message: "저장 공간 부족: " + T + " (권장: 5GB 이상)" });
      } catch {
      }
    }
    B(e.available);
    const a = await chrome.tabs.query({ active: !0, currentWindow: !0 }), i = a && a[0] ? a[0].id : null, c = /* @__PURE__ */ new Date(), l = c.getFullYear(), s = String(c.getMonth() + 1).padStart(2, "0"), m = String(c.getDate()).padStart(2, "0"), u = String(c.getHours()).padStart(2, "0"), d = String(c.getMinutes()).padStart(2, "0"), f = String(c.getSeconds()).padStart(2, "0"), g = `${l}-${s}-${m}_${u}-${d}-${f}`, h = "live_" + Date.now();
    o.channelId = h, o.active = !0, o.initSegmentProcessed = !1, o.tabId = i, o.liveChannelId = g, o.lastSegmentTime = Date.now(), o.recordingStartTime = Date.now(), o.partNumber = 1, $();
    const y = await navigator.storage.getDirectory(), E = await y.getDirectoryHandle("recordings", { create: !0 }), p = `recording_${h}.mp4`;
    o.opfsFileName = p, o.opfsFileHandle = await E.getFileHandle(p, { create: !0 }), o.opfsWritable = await o.opfsFileHandle.createWritable(), await U(), await chrome.runtime.sendMessage({ type: "INIT_FMP4_PROCESSOR" }), await chrome.storage.local.set({ isRecording: !0 });
  })().then(function() {
    n({ success: !0 });
  }).catch(function(e) {
    console.error("Failed to start recording:", e), n({ success: !1, error: e.message });
  }), !0;
  if (t.type === "SET_INIT_SEGMENT") return (async function(e) {
    if (o.active)
      try {
        const a = await fetch(e), i = await a.arrayBuffer();
        o.initSegmentData || (o.initSegmentData = i), o.initSegmentProcessed || (await o.opfsWritable.write(i), o.initSegmentProcessed = !0), await chrome.runtime.sendMessage({ type: "SET_FMP4_INIT_SEGMENT", data: Array.from(new Uint8Array(i)) }), i.byteLength;
      } catch (a) {
        throw console.error("Init segment error:", a), a;
      }
  })(t.url).then(function() {
    n({ success: !0 });
  }).catch(function(e) {
    console.error("Failed to handle init segment:", e), n({ success: !1, error: e.message });
  }), !0;
  if (t.type === "ADD_RECORDING_SEGMENT") return (async function(e) {
    if (!(!o.active || !o.initSegmentProcessed || !o.opfsWritable))
      try {
        const a = await fetch(e), i = await a.arrayBuffer();
        if (!o.opfsWritable || !o.active) return;
        const c = await chrome.runtime.sendMessage({ type: "PROCESS_FMP4_SEGMENT", data: Array.from(new Uint8Array(i)) });
        if (!o.opfsWritable || !o.active) return;
        c.error ? (c.error, await o.opfsWritable.write(i)) : await o.opfsWritable.write(new Uint8Array(c.data)), o.lastSegmentTime = Date.now(), $(), (Date.now() - o.recordingStartTime) / 6e4 >= o.segmentDuration && (o.partNumber, await _(!0), await (async function() {
          try {
            o.partNumber, o.partNumber += 1, o.recordingStartTime = Date.now();
            const l = o.channelId || "live_" + Date.now(), s = await navigator.storage.getDirectory(), m = await s.getDirectoryHandle("recordings", { create: !0 }), u = `recording_${l}_part${o.partNumber}.mp4`, d = await m.getFileHandle(u, { create: !0 }), f = await d.createWritable();
            o.opfsWritable = f, o.opfsFileHandle = d, o.opfsFileName = u, o.active = !0, o.initSegmentData ? (await f.write(o.initSegmentData), o.initSegmentProcessed = !0, o.partNumber) : o.initSegmentProcessed = !1;
          } catch (l) {
            console.error("Failed to start next recording part:", l), o.active = !1;
          }
        })()), i.byteLength;
      } catch (a) {
        if (!a.message || !a.message.includes("CLOSED")) throw console.error("Media segment error:", a), a;
      }
  })(t.url).then(function() {
    n({ success: !0 });
  }).catch(function(e) {
    console.error("Failed to handle media segment:", e), n({ success: !1, error: e.message });
  }), !0;
  if (t.type === "STOP_LIVE_RECORDING") _(), n({ success: !0 });
  else if (t.type === "HLS_SEGMENT_DETECTED") j(t.url, { clipId: t.clipId || null, pageUrl: t.pageUrl || null, tabUrl: r?.tab?.url || null }), n({ success: !0 });
  else if (t.type === "GET_DETECTED_CLIPS") n({ clips: Array.from(b.values()) });
  else {
    if (t.type === "DOWNLOAD_CLIP") return (async function(e, a, i) {
      const c = e.match(/(.*\/)([^/]+)\.ts(\?.*)?$/);
      if (!c) throw new Error("Invalid URL");
      const l = c[1], s = c[2], m = c[3] || "", u = s.match(/-(\d+)$/);
      let d;
      if (/^[a-f0-9\-]+-\d+$/.test(s) && u) {
        const S = s.substring(0, s.lastIndexOf("-")), w = u[1].length;
        d = function(D) {
          return l + S + "-" + String(D).padStart(w, "0") + ".ts" + m;
        };
      } else d = function(S) {
        return l + S + ".ts" + m;
      };
      const f = [];
      let g = 0, h = 0;
      for (; h < 3; ) try {
        const S = await fetch(d(g));
        if (!S.ok) {
          h++, g++;
          continue;
        }
        const w = await S.blob();
        f.push(w), h = 0, i && i({ stage: "downloading", current: f.length, index: g }), g++;
      } catch {
        h++, g++;
      }
      if (f.length === 0) throw new Error("No chunks");
      const y = new Blob(f, { type: "video/mp2t" });
      if (a) return { segmentCount: f.length, totalSize: y.size, blobUrl: URL.createObjectURL(y) };
      const E = "chzzk-clip-" + (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-").slice(0, -5) + ".ts", p = await y.arrayBuffer(), T = await G(p);
      return chrome.downloads.download({ url: "data:video/mp2t;base64," + T, filename: "chzzk-clips/" + E, saveAs: !0 }), { segmentCount: f.length, totalSize: y.size };
    })(t.url, t.returnData, function(e) {
      chrome.runtime.sendMessage({ type: "DOWNLOAD_PROGRESS", progress: e }).catch(function() {
      });
    }).then(function(e) {
      n({ success: !0, ...e });
    }).catch(function(e) {
      n({ success: !1, error: e.message });
    }), !0;
    if (t.type === "CLEAR_CLIPS") b.clear(), H = null, v = null, n({ success: !0 });
    else if (t.type === "REMOVE_CLIP") v = t.baseUrl, b.delete(t.baseUrl), n({ success: !0 });
    else if (t.type === "SAVE_THUMBNAIL") {
      const e = b.get(t.baseUrl);
      e && (e.thumbnailData = t.thumbnailData, b.set(t.baseUrl, e)), n({ success: !0 });
    } else {
      if (t.type === "SAVE_SCREENSHOT") return (async function(e) {
        if (!e || !e.imageData) throw new Error("Invalid screenshot payload");
        const a = await q(e.imageData), i = await x(e.id, a, a.type), c = { id: e.id, timestamp: e.timestamp, currentTime: e.currentTime, formattedCurrentTime: e.formattedCurrentTime, pageUrl: e.pageUrl, pageTitle: e.pageTitle, fileName: i, mimeType: a.type || "image/png", size: a.size }, l = await O(await I());
        let s = [c, ...l];
        for (; s.length > 0; ) try {
          return await A(s), await M(s);
        } catch (m) {
          if (!Q(m)) throw await R(i), m;
          if (s.length <= 1) throw await R(i), new Error("스크린샷 저장 공간이 부족합니다. 갤러리를 비운 뒤 다시 시도해주세요.");
          const u = s[s.length - 1];
          await R(u.fileName), s = s.slice(0, -1);
        }
        throw new Error("스크린샷 저장에 실패했습니다.");
      })(t.screenshot).then(function(e) {
        chrome.runtime.sendMessage({ type: "NEW_SCREENSHOT_CAPTURED", screenshot: e[0] }).catch(function() {
        }), n({ success: !0, screenshots: e });
      }).catch(function(e) {
        n({ success: !1, error: e.message });
      }), !0;
      if (t.type === "GET_SCREENSHOTS") return (async function() {
        const e = await I(), a = await O(e);
        return await M(a);
      })().then(function(e) {
        n({ success: !0, screenshots: e });
      }).catch(function(e) {
        n({ success: !1, error: e.message });
      }), !0;
      if (t.type === "GET_SCREENSHOT_STORAGE_USAGE") return k().then(function(e) {
        n({ success: !0, ...e });
      }).catch(function(e) {
        n({ success: !1, error: e.message });
      }), !0;
      if (t.type === "CLEANUP_SCREENSHOT_STORAGE") return (async function() {
        const e = await O(await I()), a = new Set(e.map(function(m) {
          return m.fileName;
        }).filter(Boolean));
        let i = 0;
        try {
          const m = await L(!1);
          for await (const u of m.values()) u.kind === "file" && (a.has(u.name) || (await m.removeEntry(u.name), i += 1));
        } catch {
        }
        const c = await M(e), { usageBytes: l, fileCount: s } = await k();
        return { screenshots: c, usageBytes: l, fileCount: s, removedFiles: i };
      })().then(function(e) {
        n({ success: !0, ...e });
      }).catch(function(e) {
        n({ success: !1, error: e.message });
      }), !0;
      if (t.type === "REMOVE_SCREENSHOT") return (async function(e) {
        const a = await O(await I()), i = a.find(function(l) {
          return l.id === e;
        }), c = a.filter(function(l) {
          return l.id !== e;
        });
        return i && await R(i.fileName), await A(c), await M(c);
      })(t.id).then(function(e) {
        n({ success: !0, screenshots: e });
      }).catch(function(e) {
        n({ success: !1, error: e.message });
      }), !0;
      if (t.type === "CLEAR_SCREENSHOTS") return (async function() {
        const e = await O(await I());
        for (const a of e) await R(a.fileName);
        await A([]);
      })().then(function() {
        n({ success: !0 });
      }).catch(function(e) {
        n({ success: !1, error: e.message });
      }), !0;
      if (t.type === "UPDATE_CLIP_STATUS") {
        const e = b.get(t.baseUrl);
        e && (t.downloaded !== void 0 && (e.downloaded = t.downloaded), t.failed !== void 0 && (e.failed = t.failed), b.set(t.baseUrl, e)), n({ success: !0 });
      } else if (t.type === "SHOW_TOAST") chrome.runtime.sendMessage({ type: "DISPLAY_TOAST", toastType: t.toastType, message: t.message }).catch(function() {
      }), n({ success: !0 });
      else {
        if (t.type === "RECOVER_RECORDING") return (async function(e) {
          try {
            const a = await navigator.storage.getDirectory(), i = await a.getDirectoryHandle("recordings", { create: !1 }), c = await i.getFileHandle(e), l = await c.getFile(), s = await l.arrayBuffer(), m = await G(s), u = `chzzk-recovered-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-").slice(0, -10)}.mp4`;
            await chrome.downloads.download({ url: `data:video/mp4;base64,${m}`, filename: `chzzk-recordings/${u}`, saveAs: !0 });
            const { hiddenRecordings: d = [] } = await chrome.storage.local.get("hiddenRecordings");
            return d.includes(e) || (d.push(e), await chrome.storage.local.set({ hiddenRecordings: d })), !0;
          } catch (a) {
            throw console.error("Recovery failed:", a), a;
          }
        })(t.filename).then(function() {
          n({ success: !0 });
        }).catch(function(e) {
          console.error("Failed to recover recording:", e), n({ success: !1, error: e.message });
        }), !0;
        if (t.type === "DELETE_ORPHANED_RECORDING") return (async function(e) {
          try {
            const { hiddenRecordings: a = [] } = await chrome.storage.local.get("hiddenRecordings");
            return a.includes(e) || (a.push(e), await chrome.storage.local.set({ hiddenRecordings: a })), !0;
          } catch (a) {
            throw console.error("Delete failed:", a), a;
          }
        })(t.filename).then(function() {
          n({ success: !0 });
        }).catch(function(e) {
          console.error("Failed to delete recording:", e), n({ success: !1, error: e.message });
        }), !0;
        if (t.type === "PAGE_UNLOADING_DURING_RECORDING") o.active && _(), n({ success: !0 });
        else if (t.type === "CLEAR_ALL_TEMP_FILES") return (async function() {
          try {
            let e = 0, a = 0;
            try {
              const i = await navigator.storage.getDirectory(), c = await i.getDirectoryHandle("recordings", { create: !1 }), l = [];
              for await (const s of c.values()) s.kind === "file" && l.push(s.name);
              for (const s of l) try {
                await c.removeEntry(s), e++;
              } catch {
              }
            } catch {
            }
            try {
              await U();
              const i = await chrome.runtime.sendMessage({ type: "CLEANUP_INDEXEDDB", keepKeys: [] });
              i.success ? a = i.deletedCount || 0 : console.error("IndexedDB cleanup failed:", i.error);
            } catch {
            }
            return await chrome.storage.local.remove("hiddenRecordings"), { success: !0, opfsDeleted: e, indexedDBDeleted: a };
          } catch (e) {
            return console.error("clearAllTemporaryFiles failed:", e), { success: !1, error: e.message };
          }
        })().then(function(e) {
          n(e);
        }).catch(function(e) {
          console.error("Failed to clear temp files:", e), n({ success: !1, error: e.message });
        }), !0;
      }
    }
  }
  return !0;
});
