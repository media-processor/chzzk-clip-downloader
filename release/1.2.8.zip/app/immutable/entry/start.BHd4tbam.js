import{l as s,a}from"../chunks/Deh5GcJi.js";export{s as load_css,a as start};
