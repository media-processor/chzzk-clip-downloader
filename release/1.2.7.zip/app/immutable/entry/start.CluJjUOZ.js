import{l as s,a}from"../chunks/Bo_Wk1yA.js";export{s as load_css,a as start};
