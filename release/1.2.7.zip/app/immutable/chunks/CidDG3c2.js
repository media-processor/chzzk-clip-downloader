import{h as a,a as s,b as r,E as o}from"./D9KtjqJE.js";import{B as n}from"./BGTLEIIU.js";function e(e,m,t){a&&s();var f=new n(e);r(()=>{var a=m()??null;f.ensure(a,a&&(s=>t(s,a)))},o)}export{e as c};
