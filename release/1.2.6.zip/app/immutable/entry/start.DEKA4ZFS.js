import{l as s,a}from"../chunks/CHk0MaK8.js";export{s as load_css,a as start};
