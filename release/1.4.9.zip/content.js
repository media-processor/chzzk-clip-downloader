function u(n, o) {
  o = o || "info";
  let i = document.getElementById("chzzk-toast-container");
  i || (i = document.createElement("div"), i.id = "chzzk-toast-container", i.style.cssText = "position: fixed; top: 20px; right: 20px; z-index: 999999; display: flex; flex-direction: column; gap: 10px; pointer-events: none;", document.body.appendChild(i));
  const e = document.createElement("div");
  e.style.cssText = 'background: rgba(0, 0, 0, 0.85); color: white; padding: 12px 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; font-size: 14px; min-width: 250px; max-width: 400px; pointer-events: auto; opacity: 0; transform: translateX(100%); transition: all 0.3s ease;';
  const t = { success: "#10b981", error: "#ef4444", info: "#3b82f6", warning: "#f59e0b" }, r = t[o] || t.info;
  e.style.borderLeft = "4px solid " + r;
  const s = { success: "✓", error: "✕", info: "ℹ", warning: "⚠" }, c = s[o] || s.info;
  e.innerHTML = '<div style="display: flex; align-items: center; gap: 10px;"><span style="font-size: 18px; font-weight: bold; color: ' + r + ';">' + c + '</span><span style="flex: 1;">' + n + "</span></div>", i.appendChild(e), setTimeout(function() {
    e.style.opacity = "1", e.style.transform = "translateX(0)";
  }, 10), setTimeout(function() {
    e.style.opacity = "0", e.style.transform = "translateX(100%)", setTimeout(function() {
      e.parentNode && e.parentNode.removeChild(e), i.children.length === 0 && i.parentNode && i.parentNode.removeChild(i);
    }, 300);
  }, 3e3);
}
new PerformanceObserver(function(n) {
  for (const o of n.getEntries()) if (o.entryType === "resource") {
    const i = o.name;
    i.indexOf(".ts") === -1 && i.indexOf("_chunklist.m3u8") === -1 || h(i);
  }
}).observe({ entryTypes: ["resource"] });
if (performance.getEntriesByType("resource").forEach(function(n) {
  const o = n.name;
  o.indexOf(".ts") === -1 && o.indexOf("_chunklist.m3u8") === -1 || h(o);
}), typeof window < "u") {
  const n = window.fetch, o = XMLHttpRequest.prototype.open, i = XMLHttpRequest.prototype.send;
  window._originalFetch = n, window.fetch = function(...e) {
    const t = e[0];
    return typeof t == "string" && h(t), n.apply(this, e);
  }, XMLHttpRequest.prototype.open = function(e, t, ...r) {
    return this._url = t, o.apply(this, [e, t, ...r]);
  }, XMLHttpRequest.prototype.send = function(...e) {
    return this._url && h(this._url), i.apply(this, e);
  };
}
let a = !1, p = !1, y = !1, l = /* @__PURE__ */ new Set(), m = null, _ = !0;
const f = '<svg focusable="false" xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none" aria-hidden="true" class="pzp-ui-icon__svg"><circle cx="18" cy="18" r="8" stroke="white" stroke-width="2"/><circle cx="18" cy="18" r="4" fill="white" opacity="0.4"/></svg>', T = '<svg focusable="false" xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none" aria-hidden="true" class="pzp-ui-icon__svg"><circle cx="18" cy="18" r="8" stroke="white" stroke-width="2"/><circle cx="18" cy="18" r="5" fill="#FF0000"><animate attributeName="opacity" values="1;0.4;1" dur="1s" repeatCount="indefinite" /></circle></svg>';
function g() {
  const n = document.querySelector(".pzp-pc__bottom-buttons-right"), o = document.querySelector(".pzp-pc__video-record-button");
  if (_) {
    if (n && !o) {
      const i = (function() {
        const e = document.createElement("button");
        e.className = "pzp-button pzp-pc-setting-button pzp-pc__setting-button pzp-pc__video-record-button", e.setAttribute("aria-label", "녹화 시작");
        const t = document.createElement("span");
        t.className = "pzp-button__tooltip pzp-button__tooltip--top", t.textContent = "녹화 시작";
        const r = document.createElement("span");
        return r.className = "pzp-ui-icon pzp-setting-button__icon", r.innerHTML = f, e.appendChild(t), e.appendChild(r), chrome.runtime?.id && chrome.storage?.local && chrome.storage.local.get(["isRecording"], function(s) {
          s.isRecording === !0 && (a = !0, r.innerHTML = T, t.textContent = "녹화 중지", e.setAttribute("aria-label", "녹화 중"));
        }), e.addEventListener("click", function() {
          if (!chrome.runtime?.id) return console.error("Extension context invalidated. Please reload the page."), void alert("확장 프로그램이 업데이트되었습니다. 페이지를 새로고침해주세요.");
          if (p) u("변환 중입니다. 잠시만 기다려주세요.", "warning");
          else if (!y) if (a) {
            if (l.size === 0) return u("녹화된 데이터가 없습니다. 조금 더 녹화한 후 중지해주세요.", "warning"), void chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "warning", message: "녹화된 데이터가 없습니다" }).catch(function() {
            });
            if (l.size < 4) return u("녹화 시간이 너무 짧습니다. 최소 2초 이상 녹화해주세요.", "warning"), void chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "warning", message: "녹화 시간이 너무 짧습니다" }).catch(function() {
            });
            a = !1, p = !0, e.disabled = !0, r.innerHTML = f, t.textContent = "변환 중...", e.setAttribute("aria-label", "변환 중"), chrome.runtime.sendMessage({ type: "STOP_LIVE_RECORDING" }).catch(function() {
            }), u("라이브 녹화 종료 중...", "info"), chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "info", message: "라이브 녹화 종료 중..." }).catch(function() {
            });
          } else {
            l.clear(), m = null, a = !0, y = !0, r.innerHTML = T, t.textContent = "5초동안 중단불가", e.setAttribute("aria-label", "녹화 중"), chrome.runtime.sendMessage({ type: "START_LIVE_RECORDING" }).catch(function() {
            }), u("라이브 녹화 시작", "success"), chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "success", message: "라이브 녹화 시작" }).catch(function() {
            });
            let s = 5;
            const c = setInterval(function() {
              s--, s > 0 ? t.textContent = s + "초동안 중단불가" : (clearInterval(c), y = !1, t.textContent = "녹화 중단", e.setAttribute("aria-label", "녹화 중단"));
            }, 1e3);
          }
        }), e;
      })();
      n.insertBefore(i, n.firstChild);
    }
  } else o && o.remove();
}
function h(n) {
  a && n.indexOf("_chunklist.m3u8") !== -1 && (async function(o) {
    if (o) try {
      const i = await window._originalFetch(o), e = await i.text(), t = o.split("/").slice(0, -1).join("/") + "/", r = e.split(`
`);
      for (let s = 0; s < r.length; s++) {
        let c = r[s].trim();
        if (c.indexOf('#EXT-X-MAP:URI="') === 0) {
          const d = c.match(/URI="([^"]+)"/);
          if (d) {
            const b = new URL(d[1], t).href;
            m !== b && (m = b, chrome.runtime?.id && chrome.runtime.sendMessage({ type: "SET_INIT_SEGMENT", url: m }).catch(function() {
            }));
          }
        } else if (c && c.indexOf("#") !== 0 && (c.indexOf(".m4v") !== -1 || c.indexOf(".ts") !== -1)) {
          const d = new URL(c, t).href;
          l.has(d) || (l.add(d), chrome.runtime?.id && chrome.runtime.sendMessage({ type: "ADD_RECORDING_SEGMENT", url: d }).catch(function() {
          }));
        }
      }
    } catch (i) {
      console.error(i);
    }
  })(n), (function(o) {
    if (o.indexOf(".ts") === -1) return;
    const i = o.indexOf(".pstatic.net") !== -1, e = o.indexOf("glive-clip") !== -1, t = o.indexOf("/hls/") !== -1;
    if (i && e && t) {
      if (!chrome.runtime?.id) return;
      chrome.runtime.sendMessage({ type: "HLS_SEGMENT_DETECTED", url: o }).catch(function() {
      });
    }
  })(n);
}
chrome.runtime.onMessage.addListener(function(n, o, i) {
  if (n.type === "SHOW_CONTENT_TOAST") u(n.message, n.toastType), i({ success: !0 });
  else if (n.type === "UPDATE_RECORD_BUTTON_SETTING") _ = n.enabled, g(), i({ success: !0 });
  else if (n.type === "RECORDING_COMPLETE" || n.type === "RECORDING_FAILED") {
    a = !1, p = !1;
    const e = document.querySelector(".pzp-pc__video-record-button");
    if (e) {
      const t = e.querySelector(".pzp-ui-icon"), r = e.querySelector(".pzp-button__tooltip");
      t && (t.innerHTML = f), r && (r.textContent = "녹화 시작"), e.disabled = !1, e.setAttribute("aria-label", "녹화 시작");
    }
    chrome.storage?.local && chrome.storage.local.remove("isRecording"), i({ success: !0 });
  }
  return !0;
}), window.addEventListener("beforeunload", function() {
  if (a) try {
    chrome.runtime.sendMessage({ type: "PAGE_UNLOADING_DURING_RECORDING" });
  } catch {
  }
}), window.addEventListener("unload", function() {
  if (a) try {
    chrome.runtime.sendMessage({ type: "PAGE_UNLOADING_DURING_RECORDING" });
  } catch {
  }
});
const x = new MutationObserver(function(n) {
  if (a) {
    for (const o of n) if (o.type === "childList") {
      for (const i of o.addedNodes) if (i.nodeType === Node.ELEMENT_NODE) {
        const e = i;
        if (e.tagName === "DIV" && e.classList.contains("pip_mode")) {
          a = !1, p = !0;
          const t = document.querySelector(".pzp-pc__video-record-button");
          if (t) {
            const r = t.querySelector(".pzp-ui-icon"), s = t.querySelector(".pzp-button__tooltip");
            r && (r.innerHTML = f), s && (s.textContent = "변환 중..."), t.disabled = !0, t.setAttribute("aria-label", "변환 중");
          }
          return chrome.runtime.sendMessage({ type: "STOP_LIVE_RECORDING" }).catch(function() {
          }), u("PIP 모드 감지: 라이브 녹화 종료 중...", "info"), void chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "info", message: "PIP 모드 감지: 라이브 녹화 종료 중..." }).catch(function() {
          });
        }
        if (e.querySelector("div.pip_mode")) {
          a = !1, p = !0;
          const t = document.querySelector(".pzp-pc__video-record-button");
          if (t) {
            const r = t.querySelector(".pzp-ui-icon"), s = t.querySelector(".pzp-button__tooltip");
            r && (r.innerHTML = f), s && (s.textContent = "변환 중..."), t.disabled = !0, t.setAttribute("aria-label", "변환 중");
          }
          return chrome.runtime.sendMessage({ type: "STOP_LIVE_RECORDING" }).catch(function() {
          }), u("PIP 모드 감지: 라이브 녹화 종료 중...", "info"), void chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "info", message: "PIP 모드 감지: 라이브 녹화 종료 중..." }).catch(function() {
          });
        }
      }
    }
  }
});
document.body ? x.observe(document.body, { childList: !0, subtree: !0 }) : document.addEventListener("DOMContentLoaded", function() {
  x.observe(document.body, { childList: !0, subtree: !0 });
}), (async function() {
  try {
    const n = await chrome.storage.local.get(["recordButtonEnabled"]);
    n.recordButtonEnabled !== void 0 && (_ = n.recordButtonEnabled);
  } catch (n) {
    console.error("Failed to load record button setting:", n);
  }
})().then(function() {
  setInterval(g, 1e3), g();
});
