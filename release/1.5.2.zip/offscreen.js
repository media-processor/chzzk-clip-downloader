let p = null, g = !1, y = null;
async function E() {
  if (!g) return y || (y = (async () => {
    try {
      const t = chrome.runtime.getURL("ts2mp4/ts2mp4_bg.wasm"), f = chrome.runtime.getURL("ts2mp4/ts2mp4.js"), l = await import(f), n = await fetch(t), e = await n.arrayBuffer();
      await l.default({ module_or_path: e }), p = l, g = !0;
    } catch (t) {
      throw console.error("Failed to initialize WASM:", t), y = null, t;
    }
  })(), y);
}
let h = null;
async function w(t, f) {
  return new Promise((l, n) => {
    const e = indexedDB.open(t);
    e.onerror = () => n(e.error), e.onupgradeneeded = () => {
      const r = e.result;
      r.objectStoreNames.contains(f) || r.createObjectStore(f);
    }, e.onsuccess = () => {
      const r = e.result;
      if (r.objectStoreNames.contains(f)) return void l(r);
      const c = r.version + 1;
      r.close();
      const s = indexedDB.open(t, c);
      s.onerror = () => n(s.error), s.onupgradeneeded = () => {
        const u = s.result;
        u.objectStoreNames.contains(f) || u.createObjectStore(f);
      }, s.onsuccess = () => l(s.result);
    };
  });
}
chrome.runtime.onMessage.addListener((t, f, l) => t.type === "RESET_MP4_TIMESTAMPS" ? ((async function(n, e, r) {
  try {
    if (!n || !e || !r) throw console.error("Offscreen: Invalid parameters received"), new Error("Invalid parameters");
    const c = await new Promise((o, a) => {
      w(n, e).then((d) => {
        const i = d.transaction([e], "readonly").objectStore(e).get(r);
        i.onsuccess = () => {
          d.close(), o(i.result);
        }, i.onerror = () => {
          d.close(), a(i.error);
        };
      }).catch(a);
    });
    c.byteLength;
    const s = new Uint8Array(c), u = await (async function(o) {
      if (g || await E(), !p || !p.convert_mp4_reset_timestamps_wasm) throw new Error("WASM module not properly initialized or function missing");
      try {
        o.length;
        const a = p.convert_mp4_reset_timestamps_wasm(o);
        return a.length, a;
      } catch (a) {
        throw console.error("MP4 timestamp reset failed:", a), a;
      }
    })(s);
    u.byteLength;
    const m = "result-" + r;
    return await new Promise((o, a) => {
      w(n, e).then((d) => {
        const i = d.transaction([e], "readwrite");
        i.objectStore(e).put(u.buffer, m), i.oncomplete = () => {
          d.close(), o();
        }, i.onerror = () => {
          d.close(), a(i.error);
        };
      }).catch(a);
    }), { success: !0, resultKey: m };
  } catch (c) {
    const s = c;
    return console.error("Offscreen: Reset failed", s), { success: !1, error: s.message };
  }
})(t.dbName, t.storeName, t.dataKey).then(l), !0) : t.type === "INIT_FMP4_PROCESSOR" ? ((async function() {
  try {
    await E();
    const n = await import(chrome.runtime.getURL("ts2mp4/ts2mp4.js"));
    return h = new n.FragmentedMP4ProcessorWasm(), { success: !0 };
  } catch (n) {
    const e = n;
    return console.error("Offscreen: Processor init failed", e), { success: !1, error: e.message };
  }
})().then(l), !0) : t.type === "SET_FMP4_INIT_SEGMENT" ? ((async function(n) {
  try {
    if (!h) throw new Error("Processor not initialized");
    const e = new Uint8Array(n);
    return h.set_init_segment(e), e.byteLength, { success: !0 };
  } catch (e) {
    const r = e;
    return console.error("Offscreen: Set init segment failed", r), { success: !1, error: r.message };
  }
})(t.data).then(l), !0) : t.type === "PROCESS_FMP4_SEGMENT" ? ((async function(n) {
  try {
    if (!h) throw new Error("Processor not initialized");
    const e = new Uint8Array(n), r = h.process_segment(e);
    return r.byteLength, { success: !0, data: Array.from(r) };
  } catch (e) {
    const r = e;
    return console.error("Offscreen: Segment processing failed", r), { success: !1, error: r.message };
  }
})(t.data).then(l), !0) : t.type === "DOWNLOAD_BLOB" ? ((async function(n) {
  try {
    const e = "chzzk-temp-storage", r = "video-data", c = await new Promise((s, u) => {
      w(e, r).then((m) => {
        const o = m.transaction([r], "readonly").objectStore(r).get(n);
        o.onsuccess = () => {
          m.close(), s(o.result);
        }, o.onerror = () => {
          m.close(), u(o.error);
        };
      }).catch(u);
    });
    if (!c) throw new Error("Blob not found in IndexedDB");
    return c.size, { success: !0, blobUrl: URL.createObjectURL(c) };
  } catch (e) {
    const r = e;
    return console.error("Offscreen: Download failed", r), { success: !1, error: r.message };
  }
})(t.blobKey, t.filename).then(l), !0) : t.type === "CLEANUP_INDEXEDDB" ? ((async function(n = []) {
  try {
    const e = "chzzk-temp-storage", r = "video-data", c = await new Promise((s, u) => {
      w(e, r).then((m) => {
        if (!m.objectStoreNames.contains(r)) return m.close(), void s([]);
        const o = m.transaction([r], "readwrite"), a = o.objectStore(r), d = [], i = a.getAllKeys();
        i.onsuccess = () => {
          const S = i.result;
          S.length, S.forEach((_) => {
            const b = String(_);
            n.includes(b) || (a.delete(_), d.push(b));
          }), o.oncomplete = () => {
            d.length, m.close(), s(d);
          }, o.onerror = () => {
            m.close(), u(o.error);
          };
        }, i.onerror = () => u(i.error);
      }).catch(u);
    });
    return c.length, { success: !0, deletedCount: c.length, deletedKeys: c };
  } catch (e) {
    const r = e;
    return console.error("Offscreen: Cleanup failed", r), { success: !1, error: r.message };
  }
})(t.keepKeys).then(l), !0) : void 0);
