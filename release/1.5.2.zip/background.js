const b = /* @__PURE__ */ new Map(), P = "galleryScreenshots";
let v = null;
async function U(t) {
  const o = new Blob([t], { type: "application/octet-binary" });
  return new Promise(function(r, e) {
    const a = new FileReader();
    a.onloadend = function() {
      const i = a.result;
      if (typeof i == "string") {
        const c = i.split(",")[1];
        r(c);
      } else e(new Error("Failed to convert to base64"));
    }, a.onerror = e, a.readAsDataURL(o);
  });
}
async function _(t, o) {
  return new Promise(function(r, e) {
    const a = indexedDB.open(t);
    a.onerror = function() {
      e(a.error);
    }, a.onupgradeneeded = function() {
      const i = a.result;
      i.objectStoreNames.contains(o) || i.createObjectStore(o);
    }, a.onsuccess = function() {
      const i = a.result;
      if (i.objectStoreNames.contains(o)) return void r(i);
      const c = i.version + 1;
      i.close();
      const u = indexedDB.open(t, c);
      u.onerror = function() {
        e(u.error);
      }, u.onupgradeneeded = function() {
        const l = u.result;
        l.objectStoreNames.contains(o) || l.createObjectStore(o);
      }, u.onsuccess = function() {
        r(u.result);
      };
    };
  });
}
function F(t) {
  if (t === 0) return "0 Bytes";
  const o = Math.floor(Math.log(t) / Math.log(1024));
  return parseFloat((t / Math.pow(1024, o)).toFixed(2)) + " " + ["Bytes", "KB", "MB", "GB", "TB"][o];
}
chrome.action.onClicked.addListener(function() {
  (async function() {
    if (v !== null) try {
      return await chrome.windows.get(v), void await chrome.windows.update(v, { focused: !0 });
    } catch {
      v = null;
    }
    v = (await chrome.windows.create({ url: chrome.runtime.getURL("index.html"), type: "popup", width: 600, height: 650, focused: !0 })).id ?? null, chrome.windows.onRemoved.addListener(function(o) {
      o === v && (v = null);
    });
  })();
}), chrome.webRequest.onBeforeRequest.addListener(function(t) {
  const o = t.url;
  if (o.indexOf(".ts") === -1) return;
  const r = o.indexOf(".pstatic.net") !== -1, e = o.indexOf("glive-clip") !== -1, a = o.indexOf("/hls/") !== -1;
  if (r && e && a) {
    const i = o.match(/(.*\/)([^/]+)\.ts(\?.*)?$/);
    if (i) {
      const c = i[1], u = i[2], l = /^\d+$/.test(u), m = /^[a-f0-9\-]+-\d+$/.test(u);
      if ((l || m) && !b.has(c)) {
        const s = { firstSegmentUrl: o, baseUrl: c, timestamp: Date.now(), downloaded: !1, thumbnailData: null };
        b.set(c, s), chrome.runtime.sendMessage({ type: "NEW_CLIP_DETECTED", clip: s }).catch(function() {
        });
      }
    }
  }
}, { urls: ["https://*.pstatic.net/*"] }), chrome.tabs.onRemoved.addListener(function(t) {
  n.active && n.tabId === t && N();
}), chrome.tabs.onUpdated.addListener(function(t, o, r) {
  n.active && n.tabId === t && o.url && (o.url, N());
});
let n = { active: !1, channelId: null, opfsWritable: null, opfsFileHandle: null, initSegmentProcessed: !1, initSegmentData: null, tabId: null, liveChannelId: null, lastSegmentTime: 0, inactivityTimer: null, segmentDuration: 1, recordingStartTime: 0, partNumber: 1 };
async function R() {
  const t = (await chrome.storage.local.get([P]))[P];
  return Array.isArray(t) ? t : [];
}
async function L(t = !0) {
  return await (await navigator.storage.getDirectory()).getDirectoryHandle("screenshots", { create: t });
}
async function G(t) {
  const o = await fetch(t);
  if (!o.ok) throw new Error("Failed to decode screenshot image data");
  return await o.blob();
}
async function z(t) {
  const o = await t.arrayBuffer(), r = await U(o);
  return `data:${t.type || "application/octet-stream"};base64,${r}`;
}
async function W(t, o, r) {
  const e = await L(!0), a = /* @__PURE__ */ (function(l) {
    return l === "image/jpeg" ? "jpg" : l === "image/webp" ? "webp" : "png";
  })(r || o.type), i = `${t}.${a}`, c = await e.getFileHandle(i, { create: !0 }), u = await c.createWritable();
  return await u.write(o), await u.close(), i;
}
async function $(t) {
  if (!t) return null;
  try {
    return await (await (await L(!1)).getFileHandle(t)).getFile();
  } catch {
    return null;
  }
}
async function O(t) {
  if (t) try {
    await (await L(!1)).removeEntry(t);
  } catch {
  }
}
async function I(t) {
  let o = !1;
  const r = [];
  for (const e of t) if (e.fileName) r.push(e);
  else if (e.imageData) try {
    const a = await G(e.imageData), i = await W(e.id, a, a.type);
    r.push({ ...e, fileName: i, mimeType: a.type || "image/png", size: a.size, imageData: void 0 }), o = !0;
  } catch {
    e.id, o = !0;
  }
  else o = !0;
  return o && await C(r), r;
}
async function M(t) {
  const o = [];
  let r = !1;
  for (const e of t) {
    const a = await $(e.fileName);
    if (!a) {
      r = !0;
      continue;
    }
    const i = await z(a);
    o.push({ ...e, imageData: i });
  }
  if (r) {
    const e = new Set(o.map((i) => i.id)), a = t.filter((i) => e.has(i.id));
    await C(a);
  }
  return o;
}
async function C(t) {
  await chrome.storage.local.set({ [P]: t });
}
function k(t) {
  const o = String(t?.message || t || "");
  return o.includes("QUOTA_BYTES") || o.includes("quota");
}
async function B() {
  try {
    const t = await L(!1);
    let o = 0, r = 0;
    for await (const e of t.values())
      e.kind === "file" && (o += (await e.getFile()).size, r += 1);
    return { usageBytes: o, fileCount: r };
  } catch {
    return { usageBytes: 0, fileCount: 0 };
  }
}
function H() {
  n.inactivityTimer && clearTimeout(n.inactivityTimer), n.inactivityTimer = setTimeout(function() {
    n.active && Date.now() - n.lastSegmentTime >= 3e4 && N();
  }, 3e4);
}
async function N(t = !1) {
  try {
    if (!n.active) return;
    if (!n.opfsWritable || !n.opfsFileHandle) return void console.error("No recording data to finalize");
    t || (n.active = !1);
    const o = n.partNumber, r = n.opfsWritable, e = n.opfsFileHandle;
    n.opfsWritable = null, n.opfsFileHandle = null, await r.close();
    const a = await e.getFile(), i = await a.arrayBuffer();
    i.byteLength;
    let c = i;
    try {
      await A();
      const s = "chzzk-temp-storage", d = "video-data", f = "final-recording-" + Date.now();
      {
        const g = await _(s, d);
        await new Promise(function(y, E) {
          const h = g.transaction([d], "readwrite");
          h.objectStore(d).put(i, f), h.oncomplete = function() {
            g.close(), y();
          }, h.onerror = function() {
            g.close(), E(h.error);
          };
        });
      }
      const p = await chrome.runtime.sendMessage({ type: "RESET_MP4_TIMESTAMPS", dbName: s, storeName: d, dataKey: f });
      if (p && p.success && p.resultKey) c = await new Promise(async function(g, y) {
        try {
          const E = await _(s, d), h = E.transaction([d], "readonly"), S = h.objectStore(d).get(p.resultKey);
          S.onsuccess = function() {
            const T = S.result, w = E.transaction([d], "readwrite"), D = w.objectStore(d);
            D.delete(f), D.delete(p.resultKey), w.oncomplete = function() {
              E.close(), g(T);
            }, w.onerror = function() {
              E.close(), y(w.error);
            };
          }, S.onerror = function() {
            E.close(), y(S.error);
          };
        } catch (E) {
          y(E);
        }
      }), c.byteLength;
      else {
        const g = await _(s, d), y = g.transaction([d], "readwrite");
        y.objectStore(d).delete(f), y.oncomplete = function() {
          g.close();
        };
      }
    } catch (s) {
      console.error("Failed to reset timestamps, using original data:", s);
    }
    const u = n.liveChannelId, l = "chzzk-recording/" + u + "/" + (o + ".mp4");
    (c.byteLength / 1048576).toFixed(2);
    try {
      const s = new Blob([c], { type: "video/mp4" }), d = "chzzk-temp-storage", f = "video-data", p = "download-blob-" + Date.now();
      {
        const h = await _(d, f);
        await new Promise(function(S, T) {
          const w = h.transaction([f], "readwrite"), D = w.objectStore(f).put(s, p);
          D.onsuccess = function() {
            S();
          }, D.onerror = function() {
            T(D.error);
          }, w.oncomplete = function() {
            h.close();
          }, w.onerror = function() {
            h.close();
          };
        });
      }
      await A();
      const g = await chrome.runtime.sendMessage({ type: "DOWNLOAD_BLOB", blobKey: p, filename: l });
      if (!g || !g.success || !g.blobUrl) throw new Error(g?.error || "Failed to create blob URL");
      await chrome.downloads.download({ url: g.blobUrl, filename: l, saveAs: !1 });
      const y = await _(d, f), E = y.transaction([f], "readwrite");
      E.objectStore(f).delete(p), E.oncomplete = function() {
        y.close();
      }, c.byteLength, setTimeout(async function() {
        try {
          await A();
          const h = await chrome.runtime.sendMessage({ type: "CLEANUP_INDEXEDDB", keepKeys: [] });
          h.success ? h.deletedCount : console.error("IndexedDB cleanup failed:", h.error);
        } catch (h) {
          console.error("Failed to cleanup IndexedDB:", h);
        }
      }, 5e3);
    } catch (s) {
      throw console.error("Download failed:", s), s;
    }
    t || (chrome.runtime.sendMessage({ type: "DISPLAY_TOAST", toastType: "success", message: "라이브 녹화 완료!" }).catch(function() {
    }), chrome.tabs.query({ active: !0 }).then(function(s) {
      s && s.length > 0 && s[0].id && (chrome.tabs.sendMessage(s[0].id, { type: "SHOW_CONTENT_TOAST", toastType: "success", message: "라이브 녹화 완료!" }).catch(function() {
      }), chrome.tabs.sendMessage(s[0].id, { type: "RECORDING_COMPLETE" }).catch(function() {
      }));
    }).catch(function() {
    })), n.channelId;
    const m = n.opfsFileName;
    if (t || (n.inactivityTimer && clearTimeout(n.inactivityTimer), n = { active: !1, channelId: null, opfsWritable: null, opfsFileHandle: null, initSegmentProcessed: !1, initSegmentData: null, opfsFileName: null, tabId: null, liveChannelId: null, lastSegmentTime: 0, inactivityTimer: null, segmentDuration: 1, recordingStartTime: 0, partNumber: 1 }, chrome.tabs.query({}, function(s) {
      s.forEach(function(d) {
        d.id && chrome.tabs.sendMessage(d.id, { type: "RECORDING_COMPLETE" }).catch(function() {
        });
      });
    }), await chrome.storage.local.remove("isRecording")), m) try {
      await (await (await navigator.storage.getDirectory()).getDirectoryHandle("recordings", { create: !1 })).removeEntry(m);
    } catch {
    }
  } catch (o) {
    console.error("Finalization error:", o), n.inactivityTimer && clearTimeout(n.inactivityTimer);
    try {
      await chrome.storage.local.remove("isRecording");
    } catch {
    }
    n = { active: !1, channelId: null, opfsWritable: null, liveChannelId: null, inactivityTimer: null, segmentDuration: 1, recordingStartTime: 0, partNumber: 1 }, chrome.tabs.query({ active: !0 }).then(function(r) {
      r && r.length > 0 && r[0].id && (chrome.tabs.sendMessage(r[0].id, { type: "SHOW_CONTENT_TOAST", toastType: "error", message: "녹화 처리 중 오류가 발생했습니다" }).catch(function() {
      }), chrome.tabs.sendMessage(r[0].id, { type: "RECORDING_FAILED" }).catch(function() {
      }));
    }).catch(function() {
    });
  }
}
async function A() {
  await chrome.offscreen.hasDocument() || await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["BLOBS"], justification: "WASM processing for video timestamp reset" });
}
chrome.runtime.onMessage.addListener(function(t, o, r) {
  if (t.type === "UPDATE_RECORD_BUTTON_SETTING") return chrome.tabs.query({ url: "*://chzzk.naver.com/*" }, function(e) {
    e.forEach(function(a) {
      a.id && chrome.tabs.sendMessage(a.id, { type: "UPDATE_RECORD_BUTTON_SETTING", enabled: t.enabled }).catch(function() {
      });
    });
  }), r({ success: !0 }), !0;
  if (t.type === "UPDATE_SCREENSHOT_BUTTON_SETTING") return chrome.tabs.query({ url: "*://chzzk.naver.com/*" }, function(e) {
    e.forEach(function(a) {
      a.id && chrome.tabs.sendMessage(a.id, { type: "UPDATE_SCREENSHOT_BUTTON_SETTING", enabled: t.enabled }).catch(function() {
      });
    });
  }), r({ success: !0 }), !0;
  if (t.type === "START_LIVE_RECORDING") return (async function() {
    const e = await (async function() {
      try {
        const S = await navigator.storage.estimate(), T = S.quota - S.usage;
        return { available: T, quota: S.quota, enoughSpace: T >= 5368709120 };
      } catch (S) {
        return console.error("Failed to estimate storage:", S), { available: 0, quota: 0, enoughSpace: !0 };
      }
    })();
    if (e.available, !e.enoughSpace) {
      const S = F(e.available), T = F(e.quota);
      try {
        await chrome.runtime.sendMessage({ type: "STORAGE_WARNING", available: S, quota: T });
      } catch {
      }
      try {
        const w = await chrome.tabs.query({ active: !0 });
        w && w.length > 0 && w[0].id && await chrome.tabs.sendMessage(w[0].id, { type: "SHOW_CONTENT_TOAST", toastType: "warning", message: "저장 공간 부족: " + S + " (권장: 5GB 이상)" });
      } catch {
      }
    }
    F(e.available);
    const a = await chrome.tabs.query({ active: !0, currentWindow: !0 }), i = a && a[0] ? a[0].id : null, c = /* @__PURE__ */ new Date(), u = c.getFullYear(), l = String(c.getMonth() + 1).padStart(2, "0"), m = String(c.getDate()).padStart(2, "0"), s = String(c.getHours()).padStart(2, "0"), d = String(c.getMinutes()).padStart(2, "0"), f = String(c.getSeconds()).padStart(2, "0"), p = `${u}-${l}-${m}_${s}-${d}-${f}`, g = "live_" + Date.now();
    n.channelId = g, n.active = !0, n.initSegmentProcessed = !1, n.tabId = i, n.liveChannelId = p, n.lastSegmentTime = Date.now(), n.recordingStartTime = Date.now(), n.partNumber = 1, H();
    const y = await navigator.storage.getDirectory(), E = await y.getDirectoryHandle("recordings", { create: !0 }), h = `recording_${g}.mp4`;
    n.opfsFileName = h, n.opfsFileHandle = await E.getFileHandle(h, { create: !0 }), n.opfsWritable = await n.opfsFileHandle.createWritable(), await A(), await chrome.runtime.sendMessage({ type: "INIT_FMP4_PROCESSOR" }), await chrome.storage.local.set({ isRecording: !0 });
  })().then(function() {
    r({ success: !0 });
  }).catch(function(e) {
    console.error("Failed to start recording:", e), r({ success: !1, error: e.message });
  }), !0;
  if (t.type === "SET_INIT_SEGMENT") return (async function(e) {
    if (n.active)
      try {
        const a = await fetch(e), i = await a.arrayBuffer();
        n.initSegmentData || (n.initSegmentData = i), n.initSegmentProcessed || (await n.opfsWritable.write(i), n.initSegmentProcessed = !0), await chrome.runtime.sendMessage({ type: "SET_FMP4_INIT_SEGMENT", data: Array.from(new Uint8Array(i)) }), i.byteLength;
      } catch (a) {
        throw console.error("Init segment error:", a), a;
      }
  })(t.url).then(function() {
    r({ success: !0 });
  }).catch(function(e) {
    console.error("Failed to handle init segment:", e), r({ success: !1, error: e.message });
  }), !0;
  if (t.type === "ADD_RECORDING_SEGMENT") return (async function(e) {
    if (!(!n.active || !n.initSegmentProcessed || !n.opfsWritable))
      try {
        const a = await fetch(e), i = await a.arrayBuffer();
        if (!n.opfsWritable || !n.active) return;
        const c = await chrome.runtime.sendMessage({ type: "PROCESS_FMP4_SEGMENT", data: Array.from(new Uint8Array(i)) });
        if (!n.opfsWritable || !n.active) return;
        c.error ? (c.error, await n.opfsWritable.write(i)) : await n.opfsWritable.write(new Uint8Array(c.data)), n.lastSegmentTime = Date.now(), H(), (Date.now() - n.recordingStartTime) / 6e4 >= n.segmentDuration && (n.partNumber, await N(!0), await (async function() {
          try {
            n.partNumber, n.partNumber += 1, n.recordingStartTime = Date.now();
            const u = n.channelId || "live_" + Date.now(), l = await navigator.storage.getDirectory(), m = await l.getDirectoryHandle("recordings", { create: !0 }), s = `recording_${u}_part${n.partNumber}.mp4`, d = await m.getFileHandle(s, { create: !0 }), f = await d.createWritable();
            n.opfsWritable = f, n.opfsFileHandle = d, n.opfsFileName = s, n.active = !0, n.initSegmentData ? (await f.write(n.initSegmentData), n.initSegmentProcessed = !0, n.partNumber) : n.initSegmentProcessed = !1;
          } catch (u) {
            console.error("Failed to start next recording part:", u), n.active = !1;
          }
        })()), i.byteLength;
      } catch (a) {
        if (!a.message || !a.message.includes("CLOSED")) throw console.error("Media segment error:", a), a;
      }
  })(t.url).then(function() {
    r({ success: !0 });
  }).catch(function(e) {
    console.error("Failed to handle media segment:", e), r({ success: !1, error: e.message });
  }), !0;
  if (t.type === "STOP_LIVE_RECORDING") N(), r({ success: !0 });
  else if (t.type === "HLS_SEGMENT_DETECTED") {
    const e = t.url, a = e.match(/(.*\/)([^/]+)\.ts(\?.*)?$/);
    if (a) {
      const i = a[1];
      if (!b.has(i)) {
        const c = { firstSegmentUrl: e, baseUrl: i, timestamp: Date.now(), downloaded: !1, thumbnailData: null };
        b.set(i, c), chrome.runtime.sendMessage({ type: "NEW_CLIP_DETECTED", clip: c }).catch(function() {
        });
      }
    }
    r({ success: !0 });
  } else if (t.type === "GET_DETECTED_CLIPS") r({ clips: Array.from(b.values()) });
  else {
    if (t.type === "DOWNLOAD_CLIP") return (async function(e, a, i) {
      const c = e.match(/(.*\/)([^/]+)\.ts(\?.*)?$/);
      if (!c) throw new Error("Invalid URL");
      const u = c[1], l = c[2], m = c[3] || "", s = l.match(/-(\d+)$/);
      let d;
      if (/^[a-f0-9\-]+-\d+$/.test(l) && s) {
        const T = l.substring(0, l.lastIndexOf("-")), w = s[1].length;
        d = function(D) {
          return u + T + "-" + String(D).padStart(w, "0") + ".ts" + m;
        };
      } else d = function(T) {
        return u + T + ".ts" + m;
      };
      const f = [];
      let p = 0, g = 0;
      for (; g < 3; ) try {
        const T = await fetch(d(p));
        if (!T.ok) {
          g++, p++;
          continue;
        }
        const w = await T.blob();
        f.push(w), g = 0, i && i({ stage: "downloading", current: f.length, index: p }), p++;
      } catch {
        g++, p++;
      }
      if (f.length === 0) throw new Error("No chunks");
      const y = new Blob(f, { type: "video/mp2t" });
      if (a) return { segmentCount: f.length, totalSize: y.size, blobUrl: URL.createObjectURL(y) };
      const E = "chzzk-clip-" + (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-").slice(0, -5) + ".ts", h = await y.arrayBuffer(), S = await U(h);
      return chrome.downloads.download({ url: "data:video/mp2t;base64," + S, filename: "chzzk-clips/" + E, saveAs: !0 }), { segmentCount: f.length, totalSize: y.size };
    })(t.url, t.returnData, function(e) {
      chrome.runtime.sendMessage({ type: "DOWNLOAD_PROGRESS", progress: e }).catch(function() {
      });
    }).then(function(e) {
      r({ success: !0, ...e });
    }).catch(function(e) {
      r({ success: !1, error: e.message });
    }), !0;
    if (t.type === "CLEAR_CLIPS") b.clear(), r({ success: !0 });
    else if (t.type === "REMOVE_CLIP") b.delete(t.baseUrl), r({ success: !0 });
    else if (t.type === "SAVE_THUMBNAIL") {
      const e = b.get(t.baseUrl);
      e && (e.thumbnailData = t.thumbnailData, b.set(t.baseUrl, e)), r({ success: !0 });
    } else {
      if (t.type === "SAVE_SCREENSHOT") return (async function(e) {
        if (!e || !e.imageData) throw new Error("Invalid screenshot payload");
        const a = await G(e.imageData), i = await W(e.id, a, a.type), c = { id: e.id, timestamp: e.timestamp, currentTime: e.currentTime, formattedCurrentTime: e.formattedCurrentTime, pageUrl: e.pageUrl, pageTitle: e.pageTitle, fileName: i, mimeType: a.type || "image/png", size: a.size }, u = await I(await R());
        let l = [c, ...u];
        for (; l.length > 0; ) try {
          return await C(l), await M(l);
        } catch (m) {
          if (!k(m)) throw await O(i), m;
          if (l.length <= 1) throw await O(i), new Error("스크린샷 저장 공간이 부족합니다. 갤러리를 비운 뒤 다시 시도해주세요.");
          const s = l[l.length - 1];
          await O(s.fileName), l = l.slice(0, -1);
        }
        throw new Error("스크린샷 저장에 실패했습니다.");
      })(t.screenshot).then(function(e) {
        chrome.runtime.sendMessage({ type: "NEW_SCREENSHOT_CAPTURED", screenshot: e[0] }).catch(function() {
        }), r({ success: !0, screenshots: e });
      }).catch(function(e) {
        r({ success: !1, error: e.message });
      }), !0;
      if (t.type === "GET_SCREENSHOTS") return (async function() {
        const e = await R(), a = await I(e);
        return await M(a);
      })().then(function(e) {
        r({ success: !0, screenshots: e });
      }).catch(function(e) {
        r({ success: !1, error: e.message });
      }), !0;
      if (t.type === "GET_SCREENSHOT_STORAGE_USAGE") return B().then(function(e) {
        r({ success: !0, ...e });
      }).catch(function(e) {
        r({ success: !1, error: e.message });
      }), !0;
      if (t.type === "CLEANUP_SCREENSHOT_STORAGE") return (async function() {
        const e = await I(await R()), a = new Set(e.map(function(m) {
          return m.fileName;
        }).filter(Boolean));
        let i = 0;
        try {
          const m = await L(!1);
          for await (const s of m.values()) s.kind === "file" && (a.has(s.name) || (await m.removeEntry(s.name), i += 1));
        } catch {
        }
        const c = await M(e), { usageBytes: u, fileCount: l } = await B();
        return { screenshots: c, usageBytes: u, fileCount: l, removedFiles: i };
      })().then(function(e) {
        r({ success: !0, ...e });
      }).catch(function(e) {
        r({ success: !1, error: e.message });
      }), !0;
      if (t.type === "REMOVE_SCREENSHOT") return (async function(e) {
        const a = await I(await R()), i = a.find(function(u) {
          return u.id === e;
        }), c = a.filter(function(u) {
          return u.id !== e;
        });
        return i && await O(i.fileName), await C(c), await M(c);
      })(t.id).then(function(e) {
        r({ success: !0, screenshots: e });
      }).catch(function(e) {
        r({ success: !1, error: e.message });
      }), !0;
      if (t.type === "CLEAR_SCREENSHOTS") return (async function() {
        const e = await I(await R());
        for (const a of e) await O(a.fileName);
        await C([]);
      })().then(function() {
        r({ success: !0 });
      }).catch(function(e) {
        r({ success: !1, error: e.message });
      }), !0;
      if (t.type === "UPDATE_CLIP_STATUS") {
        const e = b.get(t.baseUrl);
        e && (t.downloaded !== void 0 && (e.downloaded = t.downloaded), t.failed !== void 0 && (e.failed = t.failed), b.set(t.baseUrl, e)), r({ success: !0 });
      } else if (t.type === "SHOW_TOAST") chrome.runtime.sendMessage({ type: "DISPLAY_TOAST", toastType: t.toastType, message: t.message }).catch(function() {
      }), r({ success: !0 });
      else {
        if (t.type === "RECOVER_RECORDING") return (async function(e) {
          try {
            const a = await navigator.storage.getDirectory(), i = await a.getDirectoryHandle("recordings", { create: !1 }), c = await i.getFileHandle(e), u = await c.getFile(), l = await u.arrayBuffer(), m = await U(l), s = `chzzk-recovered-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-").slice(0, -10)}.mp4`;
            await chrome.downloads.download({ url: `data:video/mp4;base64,${m}`, filename: `chzzk-recordings/${s}`, saveAs: !0 });
            const { hiddenRecordings: d = [] } = await chrome.storage.local.get("hiddenRecordings");
            return d.includes(e) || (d.push(e), await chrome.storage.local.set({ hiddenRecordings: d })), !0;
          } catch (a) {
            throw console.error("Recovery failed:", a), a;
          }
        })(t.filename).then(function() {
          r({ success: !0 });
        }).catch(function(e) {
          console.error("Failed to recover recording:", e), r({ success: !1, error: e.message });
        }), !0;
        if (t.type === "DELETE_ORPHANED_RECORDING") return (async function(e) {
          try {
            const { hiddenRecordings: a = [] } = await chrome.storage.local.get("hiddenRecordings");
            return a.includes(e) || (a.push(e), await chrome.storage.local.set({ hiddenRecordings: a })), !0;
          } catch (a) {
            throw console.error("Delete failed:", a), a;
          }
        })(t.filename).then(function() {
          r({ success: !0 });
        }).catch(function(e) {
          console.error("Failed to delete recording:", e), r({ success: !1, error: e.message });
        }), !0;
        if (t.type === "PAGE_UNLOADING_DURING_RECORDING") n.active && N(), r({ success: !0 });
        else if (t.type === "CLEAR_ALL_TEMP_FILES") return (async function() {
          try {
            let e = 0, a = 0;
            try {
              const i = await navigator.storage.getDirectory(), c = await i.getDirectoryHandle("recordings", { create: !1 }), u = [];
              for await (const l of c.values()) l.kind === "file" && u.push(l.name);
              for (const l of u) try {
                await c.removeEntry(l), e++;
              } catch {
              }
            } catch {
            }
            try {
              await A();
              const i = await chrome.runtime.sendMessage({ type: "CLEANUP_INDEXEDDB", keepKeys: [] });
              i.success ? a = i.deletedCount || 0 : console.error("IndexedDB cleanup failed:", i.error);
            } catch {
            }
            return await chrome.storage.local.remove("hiddenRecordings"), { success: !0, opfsDeleted: e, indexedDBDeleted: a };
          } catch (e) {
            return console.error("clearAllTemporaryFiles failed:", e), { success: !1, error: e.message };
          }
        })().then(function(e) {
          r(e);
        }).catch(function(e) {
          console.error("Failed to clear temp files:", e), r({ success: !1, error: e.message });
        }), !0;
      }
    }
  }
  return !0;
});
