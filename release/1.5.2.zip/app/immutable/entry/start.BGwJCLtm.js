import{l as s,a}from"../chunks/B8RkoxrS.js";export{s as load_css,a as start};
