import{l as s,a}from"../chunks/B1EDia_F.js";export{s as load_css,a as start};
