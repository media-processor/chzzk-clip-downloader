let p = null, w = !1, y = null;
async function b() {
  if (!w) return y || (y = (async () => {
    try {
      const t = chrome.runtime.getURL("ts2mp4/ts2mp4_bg.wasm"), g = chrome.runtime.getURL("ts2mp4/ts2mp4.js"), l = await import(g), n = await fetch(t), e = await n.arrayBuffer();
      await l.default({ module_or_path: e }), p = l, w = !0;
    } catch (t) {
      throw console.error("Failed to initialize WASM:", t), y = null, t;
    }
  })(), y);
}
let f = null;
chrome.runtime.onMessage.addListener((t, g, l) => t.type === "RESET_MP4_TIMESTAMPS" ? ((async function(n, e, r) {
  try {
    if (!n || !e || !r) throw console.error("Offscreen: Invalid parameters received"), new Error("Invalid parameters");
    const a = await new Promise((s, o) => {
      const u = indexedDB.open(n, 1);
      u.onerror = () => o(u.error), u.onsuccess = () => {
        const c = u.result.transaction([e], "readonly").objectStore(e).get(r);
        c.onsuccess = () => s(c.result), c.onerror = () => o(c.error);
      };
    });
    a.byteLength;
    const m = new Uint8Array(a), d = await (async function(s) {
      if (w || await b(), !p || !p.convert_mp4_reset_timestamps_wasm) throw new Error("WASM module not properly initialized or function missing");
      try {
        s.length;
        const o = p.convert_mp4_reset_timestamps_wasm(s);
        return o.length, o;
      } catch (o) {
        throw console.error("MP4 timestamp reset failed:", o), o;
      }
    })(m);
    d.byteLength;
    const i = "result-" + r;
    return await new Promise((s, o) => {
      const u = indexedDB.open(n, 1);
      u.onerror = () => o(u.error), u.onsuccess = () => {
        const c = u.result.transaction([e], "readwrite");
        c.objectStore(e).put(d.buffer, i), c.oncomplete = () => s(), c.onerror = () => o(c.error);
      };
    }), { success: !0, resultKey: i };
  } catch (a) {
    const m = a;
    return console.error("Offscreen: Reset failed", m), { success: !1, error: m.message };
  }
})(t.dbName, t.storeName, t.dataKey).then(l), !0) : t.type === "INIT_FMP4_PROCESSOR" ? ((async function() {
  try {
    await b();
    const n = await import(chrome.runtime.getURL("ts2mp4/ts2mp4.js"));
    return f = new n.FragmentedMP4ProcessorWasm(), { success: !0 };
  } catch (n) {
    const e = n;
    return console.error("Offscreen: Processor init failed", e), { success: !1, error: e.message };
  }
})().then(l), !0) : t.type === "SET_FMP4_INIT_SEGMENT" ? ((async function(n) {
  try {
    if (!f) throw new Error("Processor not initialized");
    const e = new Uint8Array(n);
    return f.set_init_segment(e), e.byteLength, { success: !0 };
  } catch (e) {
    const r = e;
    return console.error("Offscreen: Set init segment failed", r), { success: !1, error: r.message };
  }
})(t.data).then(l), !0) : t.type === "PROCESS_FMP4_SEGMENT" ? ((async function(n) {
  try {
    if (!f) throw new Error("Processor not initialized");
    const e = new Uint8Array(n), r = f.process_segment(e);
    return r.byteLength, { success: !0, data: Array.from(r) };
  } catch (e) {
    const r = e;
    return console.error("Offscreen: Segment processing failed", r), { success: !1, error: r.message };
  }
})(t.data).then(l), !0) : t.type === "DOWNLOAD_BLOB" ? ((async function(n) {
  try {
    const e = "chzzk-temp-storage", r = "video-data", a = await new Promise((m, d) => {
      const i = indexedDB.open(e, 1);
      i.onerror = () => d(i.error), i.onsuccess = () => {
        const s = i.result.transaction([r], "readonly").objectStore(r).get(n);
        s.onsuccess = () => m(s.result), s.onerror = () => d(s.error);
      };
    });
    if (!a) throw new Error("Blob not found in IndexedDB");
    return a.size, { success: !0, blobUrl: URL.createObjectURL(a) };
  } catch (e) {
    const r = e;
    return console.error("Offscreen: Download failed", r), { success: !1, error: r.message };
  }
})(t.blobKey, t.filename).then(l), !0) : t.type === "CLEANUP_INDEXEDDB" ? ((async function(n = []) {
  try {
    const e = "chzzk-temp-storage", r = "video-data", a = await new Promise((m, d) => {
      const i = indexedDB.open(e, 1);
      i.onerror = () => d(i.error), i.onsuccess = () => {
        const s = i.result;
        if (!s.objectStoreNames.contains(r)) return void m([]);
        const o = s.transaction([r], "readwrite"), u = o.objectStore(r), c = [], h = u.getAllKeys();
        h.onsuccess = () => {
          const _ = h.result;
          _.length, _.forEach((S) => {
            const E = String(S);
            n.includes(E) || (u.delete(S), c.push(E));
          }), o.oncomplete = () => {
            c.length, m(c);
          }, o.onerror = () => d(o.error);
        }, h.onerror = () => d(h.error);
      };
    });
    return a.length, { success: !0, deletedCount: a.length, deletedKeys: a };
  } catch (e) {
    const r = e;
    return console.error("Offscreen: Cleanup failed", r), { success: !1, error: r.message };
  }
})(t.keepKeys).then(l), !0) : void 0);
