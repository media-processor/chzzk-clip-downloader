function u(i, o) {
  o = o || "info";
  let t = document.getElementById("chzzk-toast-container");
  t || (t = document.createElement("div"), t.id = "chzzk-toast-container", t.style.cssText = "position: fixed; top: 20px; right: 20px; z-index: 999999; display: flex; flex-direction: column; gap: 10px; pointer-events: none;", document.body.appendChild(t));
  const e = document.createElement("div");
  e.style.cssText = 'background: rgba(0, 0, 0, 0.85); color: white; padding: 12px 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; font-size: 14px; min-width: 250px; max-width: 400px; pointer-events: auto; opacity: 0; transform: translateX(100%); transition: all 0.3s ease;';
  const n = { success: "#10b981", error: "#ef4444", info: "#3b82f6", warning: "#f59e0b" }, s = n[o] || n.info;
  e.style.borderLeft = "4px solid " + s;
  const r = { success: "✓", error: "✕", info: "ℹ", warning: "⚠" }, a = r[o] || r.info;
  e.innerHTML = '<div style="display: flex; align-items: center; gap: 10px;"><span style="font-size: 18px; font-weight: bold; color: ' + s + ';">' + a + '</span><span style="flex: 1;">' + i + "</span></div>", t.appendChild(e), setTimeout(function() {
    e.style.opacity = "1", e.style.transform = "translateX(0)";
  }, 10), setTimeout(function() {
    e.style.opacity = "0", e.style.transform = "translateX(100%)", setTimeout(function() {
      e.parentNode && e.parentNode.removeChild(e), t.children.length === 0 && t.parentNode && t.parentNode.removeChild(t);
    }, 300);
  }, 3e3);
}
new PerformanceObserver(function(i) {
  for (const o of i.getEntries()) if (o.entryType === "resource") {
    const t = o.name;
    t.indexOf(".ts") === -1 && t.indexOf("_chunklist.m3u8") === -1 || h(t);
  }
}).observe({ entryTypes: ["resource"] });
if (performance.getEntriesByType("resource").forEach(function(i) {
  const o = i.name;
  o.indexOf(".ts") === -1 && o.indexOf("_chunklist.m3u8") === -1 || h(o);
}), typeof window < "u") {
  const i = window.fetch, o = XMLHttpRequest.prototype.open, t = XMLHttpRequest.prototype.send;
  window._originalFetch = i, window.fetch = function(...e) {
    const n = e[0];
    return typeof n == "string" && h(n), i.apply(this, e);
  }, XMLHttpRequest.prototype.open = function(e, n, ...s) {
    return this._url = n, o.apply(this, [e, n, ...s]);
  }, XMLHttpRequest.prototype.send = function(...e) {
    return this._url && h(this._url), t.apply(this, e);
  };
}
let c = !1, l = !1, y = !1, p = /* @__PURE__ */ new Set(), m = null;
const f = '<svg focusable="false" xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none" aria-hidden="true" class="pzp-ui-icon__svg"><circle cx="18" cy="18" r="8" stroke="white" stroke-width="2"/><circle cx="18" cy="18" r="4" fill="white" opacity="0.4"/></svg>', _ = '<svg focusable="false" xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none" aria-hidden="true" class="pzp-ui-icon__svg"><circle cx="18" cy="18" r="8" stroke="white" stroke-width="2"/><circle cx="18" cy="18" r="5" fill="#FF0000"><animate attributeName="opacity" values="1;0.4;1" dur="1s" repeatCount="indefinite" /></circle></svg>';
function b() {
  const i = document.querySelector(".pzp-pc__bottom-buttons-right");
  if (i && !document.querySelector(".pzp-pc__video-record-button")) {
    const o = (function() {
      const t = document.createElement("button");
      t.className = "pzp-button pzp-pc-setting-button pzp-pc__setting-button pzp-pc__video-record-button", t.setAttribute("aria-label", "녹화 시작");
      const e = document.createElement("span");
      e.className = "pzp-button__tooltip pzp-button__tooltip--top", e.textContent = "녹화 시작";
      const n = document.createElement("span");
      return n.className = "pzp-ui-icon pzp-setting-button__icon", n.innerHTML = f, t.appendChild(e), t.appendChild(n), chrome.runtime?.id && chrome.storage?.local && chrome.storage.local.get(["isRecording"], function(s) {
        s.isRecording === !0 && (c = !0, n.innerHTML = _, e.textContent = "녹화 중지", t.setAttribute("aria-label", "녹화 중"));
      }), t.addEventListener("click", function() {
        if (!chrome.runtime?.id) return console.error("Extension context invalidated. Please reload the page."), void alert("확장 프로그램이 업데이트되었습니다. 페이지를 새로고침해주세요.");
        if (l) u("변환 중입니다. 잠시만 기다려주세요.", "warning");
        else if (!y) if (c) {
          if (p.size === 0) return u("녹화된 데이터가 없습니다. 조금 더 녹화한 후 중지해주세요.", "warning"), void chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "warning", message: "녹화된 데이터가 없습니다" }).catch(function() {
          });
          if (p.size < 4) return u("녹화 시간이 너무 짧습니다. 최소 2초 이상 녹화해주세요.", "warning"), void chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "warning", message: "녹화 시간이 너무 짧습니다" }).catch(function() {
          });
          c = !1, l = !0, t.disabled = !0, n.innerHTML = f, e.textContent = "변환 중...", t.setAttribute("aria-label", "변환 중"), chrome.runtime.sendMessage({ type: "STOP_LIVE_RECORDING" }).catch(function() {
          }), u("라이브 녹화 종료 중...", "info"), chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "info", message: "라이브 녹화 종료 중..." }).catch(function() {
          });
        } else {
          p.clear(), m = null, c = !0, y = !0, n.innerHTML = _, e.textContent = "5초동안 중단불가", t.setAttribute("aria-label", "녹화 중"), chrome.runtime.sendMessage({ type: "START_LIVE_RECORDING" }).catch(function() {
          }), u("라이브 녹화 시작", "success"), chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "success", message: "라이브 녹화 시작" }).catch(function() {
          });
          let s = 5;
          const r = setInterval(function() {
            s--, s > 0 ? e.textContent = s + "초동안 중단불가" : (clearInterval(r), y = !1, e.textContent = "녹화 중단", t.setAttribute("aria-label", "녹화 중단"));
          }, 1e3);
        }
      }), t;
    })();
    i.insertBefore(o, i.firstChild);
  }
}
function h(i) {
  c && i.indexOf("_chunklist.m3u8") !== -1 && (async function(o) {
    if (o) try {
      const t = await window._originalFetch(o), e = await t.text(), n = o.split("/").slice(0, -1).join("/") + "/", s = e.split(`
`);
      for (let r = 0; r < s.length; r++) {
        let a = s[r].trim();
        if (a.indexOf('#EXT-X-MAP:URI="') === 0) {
          const d = a.match(/URI="([^"]+)"/);
          if (d) {
            const g = new URL(d[1], n).href;
            m !== g && (m = g, chrome.runtime?.id && chrome.runtime.sendMessage({ type: "SET_INIT_SEGMENT", url: m }).catch(function() {
            }));
          }
        } else if (a && a.indexOf("#") !== 0 && (a.indexOf(".m4v") !== -1 || a.indexOf(".ts") !== -1)) {
          const d = new URL(a, n).href;
          p.has(d) || (p.add(d), chrome.runtime?.id && chrome.runtime.sendMessage({ type: "ADD_RECORDING_SEGMENT", url: d }).catch(function() {
          }));
        }
      }
    } catch (t) {
      console.error(t);
    }
  })(i), (function(o) {
    if (o.indexOf(".ts") === -1) return;
    const t = o.indexOf(".pstatic.net") !== -1, e = o.indexOf("glive-clip") !== -1, n = o.indexOf("/hls/") !== -1;
    if (t && e && n) {
      if (!chrome.runtime?.id) return;
      chrome.runtime.sendMessage({ type: "HLS_SEGMENT_DETECTED", url: o }).catch(function() {
      });
    }
  })(i);
}
chrome.runtime.onMessage.addListener(function(i, o, t) {
  if (i.type === "SHOW_CONTENT_TOAST") u(i.message, i.toastType), t({ success: !0 });
  else if (i.type === "RECORDING_COMPLETE" || i.type === "RECORDING_FAILED") {
    c = !1, l = !1;
    const e = document.querySelector(".pzp-pc__video-record-button");
    if (e) {
      const n = e.querySelector(".pzp-ui-icon"), s = e.querySelector(".pzp-button__tooltip");
      n && (n.innerHTML = f), s && (s.textContent = "녹화 시작"), e.disabled = !1, e.setAttribute("aria-label", "녹화 시작");
    }
    chrome.storage?.local && chrome.storage.local.remove("isRecording"), t({ success: !0 });
  }
  return !0;
}), window.addEventListener("beforeunload", function() {
  if (c) try {
    chrome.runtime.sendMessage({ type: "PAGE_UNLOADING_DURING_RECORDING" });
  } catch {
  }
}), window.addEventListener("unload", function() {
  if (c) try {
    chrome.runtime.sendMessage({ type: "PAGE_UNLOADING_DURING_RECORDING" });
  } catch {
  }
});
const x = new MutationObserver(function(i) {
  if (c) {
    for (const o of i) if (o.type === "childList") {
      for (const t of o.addedNodes) if (t.nodeType === Node.ELEMENT_NODE) {
        const e = t;
        if (e.tagName === "DIV" && e.classList.contains("pip_mode")) {
          c = !1, l = !0;
          const n = document.querySelector(".pzp-pc__video-record-button");
          if (n) {
            const s = n.querySelector(".pzp-ui-icon"), r = n.querySelector(".pzp-button__tooltip");
            s && (s.innerHTML = f), r && (r.textContent = "변환 중..."), n.disabled = !0, n.setAttribute("aria-label", "변환 중");
          }
          return chrome.runtime.sendMessage({ type: "STOP_LIVE_RECORDING" }).catch(function() {
          }), u("PIP 모드 감지: 라이브 녹화 종료 중...", "info"), void chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "info", message: "PIP 모드 감지: 라이브 녹화 종료 중..." }).catch(function() {
          });
        }
        if (e.querySelector("div.pip_mode")) {
          c = !1, l = !0;
          const n = document.querySelector(".pzp-pc__video-record-button");
          if (n) {
            const s = n.querySelector(".pzp-ui-icon"), r = n.querySelector(".pzp-button__tooltip");
            s && (s.innerHTML = f), r && (r.textContent = "변환 중..."), n.disabled = !0, n.setAttribute("aria-label", "변환 중");
          }
          return chrome.runtime.sendMessage({ type: "STOP_LIVE_RECORDING" }).catch(function() {
          }), u("PIP 모드 감지: 라이브 녹화 종료 중...", "info"), void chrome.runtime.sendMessage({ type: "SHOW_TOAST", toastType: "info", message: "PIP 모드 감지: 라이브 녹화 종료 중..." }).catch(function() {
          });
        }
      }
    }
  }
});
document.body ? x.observe(document.body, { childList: !0, subtree: !0 }) : document.addEventListener("DOMContentLoaded", function() {
  x.observe(document.body, { childList: !0, subtree: !0 });
}), setInterval(b, 1e3), b();
