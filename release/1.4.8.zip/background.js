const D = /* @__PURE__ */ new Map();
let E = null;
async function N(n) {
  const d = new Blob([n], { type: "application/octet-binary" });
  return new Promise(function(o, t) {
    const a = new FileReader();
    a.onloadend = function() {
      const r = a.result;
      if (typeof r == "string") {
        const i = r.split(",")[1];
        o(i);
      } else t(new Error("Failed to convert to base64"));
    }, a.onerror = t, a.readAsDataURL(d);
  });
}
function I(n) {
  if (n === 0) return "0 Bytes";
  const d = Math.floor(Math.log(n) / Math.log(1024));
  return parseFloat((n / Math.pow(1024, d)).toFixed(2)) + " " + ["Bytes", "KB", "MB", "GB", "TB"][d];
}
chrome.action.onClicked.addListener(function() {
  (async function() {
    if (E !== null) try {
      return await chrome.windows.get(E), void await chrome.windows.update(E, { focused: !0 });
    } catch {
      E = null;
    }
    E = (await chrome.windows.create({ url: chrome.runtime.getURL("index.html"), type: "popup", width: 600, height: 650, focused: !0 })).id ?? null, chrome.windows.onRemoved.addListener(function(d) {
      d === E && (E = null);
    });
  })();
}), chrome.webRequest.onBeforeRequest.addListener(function(n) {
  const d = n.url;
  if (d.indexOf(".ts") === -1) return;
  const o = d.indexOf(".pstatic.net") !== -1, t = d.indexOf("glive-clip") !== -1, a = d.indexOf("/hls/") !== -1;
  if (o && t && a) {
    const r = d.match(/(.*\/)([^/]+)\.ts(\?.*)?$/);
    if (r) {
      const i = r[1], p = r[2], f = /^\d+$/.test(p), S = /^[a-f0-9\-]+-\d+$/.test(p);
      if ((f || S) && !D.has(i)) {
        const s = { firstSegmentUrl: d, baseUrl: i, timestamp: Date.now(), downloaded: !1, thumbnailData: null };
        D.set(i, s), chrome.runtime.sendMessage({ type: "NEW_CLIP_DETECTED", clip: s }).catch(function() {
        });
      }
    }
  }
}, { urls: ["https://*.pstatic.net/*"] }), chrome.tabs.onRemoved.addListener(function(n) {
  e.active && e.tabId === n && v();
}), chrome.tabs.onUpdated.addListener(function(n, d, o) {
  e.active && e.tabId === n && d.url && (d.url, v());
});
let e = { active: !1, channelId: null, opfsWritable: null, opfsFileHandle: null, initSegmentProcessed: !1, initSegmentData: null, tabId: null, liveChannelId: null, lastSegmentTime: 0, inactivityTimer: null, segmentDuration: 1, recordingStartTime: 0, partNumber: 1 };
function R() {
  e.inactivityTimer && clearTimeout(e.inactivityTimer), e.inactivityTimer = setTimeout(function() {
    e.active && Date.now() - e.lastSegmentTime >= 3e4 && v();
  }, 3e4);
}
async function v(n = !1) {
  try {
    if (!e.active) return;
    if (!e.opfsWritable || !e.opfsFileHandle) return void console.error("No recording data to finalize");
    n || (e.active = !1);
    const d = e.partNumber, o = e.opfsWritable, t = e.opfsFileHandle;
    e.opfsWritable = null, e.opfsFileHandle = null, await o.close();
    const a = await t.getFile(), r = await a.arrayBuffer();
    r.byteLength;
    let i = r;
    try {
      await _();
      const s = "chzzk-temp-storage", c = "video-data", m = "final-recording-" + Date.now();
      await new Promise(function(g, b) {
        const u = indexedDB.open(s, 1);
        u.onerror = function() {
          b(u.error);
        }, u.onsuccess = function() {
          const y = u.result.transaction([c], "readwrite");
          y.objectStore(c).put(r, m), y.oncomplete = function() {
            g();
          }, y.onerror = function() {
            b(y.error);
          };
        }, u.onupgradeneeded = function(y) {
          const l = y.target.result;
          l.objectStoreNames.contains(c) || l.createObjectStore(c);
        };
      });
      const w = await chrome.runtime.sendMessage({ type: "RESET_MP4_TIMESTAMPS", dbName: s, storeName: c, dataKey: m });
      if (w && w.success && w.resultKey) i = await new Promise(function(g, b) {
        const u = indexedDB.open(s, 1);
        u.onerror = function() {
          b(u.error);
        }, u.onsuccess = function() {
          const y = u.result, l = y.transaction([c], "readonly").objectStore(c).get(w.resultKey);
          l.onsuccess = function() {
            const h = y.transaction([c], "readwrite").objectStore(c);
            h.delete(m), h.delete(w.resultKey), g(l.result);
          }, l.onerror = function() {
            b(l.error);
          };
        };
      }), i.byteLength;
      else {
        const g = indexedDB.open(s, 1);
        g.onsuccess = function() {
          g.result.transaction([c], "readwrite").objectStore(c).delete(m);
        };
      }
    } catch (s) {
      console.error("Failed to reset timestamps, using original data:", s);
    }
    const p = e.liveChannelId, f = "chzzk-recording/" + p + "/" + (d + ".mp4");
    (i.byteLength / 1048576).toFixed(2);
    try {
      const s = new Blob([i], { type: "video/mp4" }), c = "chzzk-temp-storage", m = "video-data", w = "download-blob-" + Date.now();
      await new Promise(function(u, y) {
        const l = indexedDB.open(c, 1);
        l.onerror = function() {
          y(l.error);
        }, l.onsuccess = function() {
          const h = l.result.transaction([m], "readwrite").objectStore(m).put(s, w);
          h.onsuccess = function() {
            u();
          }, h.onerror = function() {
            y(h.error);
          };
        };
      }), await _();
      const g = await chrome.runtime.sendMessage({ type: "DOWNLOAD_BLOB", blobKey: w, filename: f });
      if (!g || !g.success || !g.blobUrl) throw new Error("Failed to create blob URL");
      await chrome.downloads.download({ url: g.blobUrl, filename: f, saveAs: !1 });
      const b = indexedDB.open(c, 1);
      b.onsuccess = function() {
        b.result.transaction([m], "readwrite").objectStore(m).delete(w);
      }, i.byteLength, setTimeout(async function() {
        try {
          await _();
          const u = await chrome.runtime.sendMessage({ type: "CLEANUP_INDEXEDDB", keepKeys: [] });
          u.success ? u.deletedCount : console.error("IndexedDB cleanup failed:", u.error);
        } catch (u) {
          console.error("Failed to cleanup IndexedDB:", u);
        }
      }, 5e3);
    } catch (s) {
      throw console.error("Download failed:", s), s;
    }
    n || (chrome.runtime.sendMessage({ type: "DISPLAY_TOAST", toastType: "success", message: "라이브 녹화 완료!" }).catch(function() {
    }), chrome.tabs.query({ active: !0 }).then(function(s) {
      s && s.length > 0 && s[0].id && (chrome.tabs.sendMessage(s[0].id, { type: "SHOW_CONTENT_TOAST", toastType: "success", message: "라이브 녹화 완료!" }).catch(function() {
      }), chrome.tabs.sendMessage(s[0].id, { type: "RECORDING_COMPLETE" }).catch(function() {
      }));
    }).catch(function() {
    })), e.channelId;
    const S = e.opfsFileName;
    if (n || (e.inactivityTimer && clearTimeout(e.inactivityTimer), e = { active: !1, channelId: null, opfsWritable: null, opfsFileHandle: null, initSegmentProcessed: !1, initSegmentData: null, opfsFileName: null, tabId: null, liveChannelId: null, lastSegmentTime: 0, inactivityTimer: null, segmentDuration: 1, recordingStartTime: 0, partNumber: 1 }, chrome.tabs.query({}, function(s) {
      s.forEach(function(c) {
        c.id && chrome.tabs.sendMessage(c.id, { type: "RECORDING_COMPLETE" }).catch(function() {
        });
      });
    }), await chrome.storage.local.remove("isRecording")), S) try {
      await (await (await navigator.storage.getDirectory()).getDirectoryHandle("recordings", { create: !1 })).removeEntry(S);
    } catch {
    }
  } catch (d) {
    console.error("Finalization error:", d), e.inactivityTimer && clearTimeout(e.inactivityTimer);
    try {
      await chrome.storage.local.remove("isRecording");
    } catch {
    }
    e = { active: !1, channelId: null, opfsWritable: null, liveChannelId: null, inactivityTimer: null, segmentDuration: 1, recordingStartTime: 0, partNumber: 1 }, chrome.tabs.query({ active: !0 }).then(function(o) {
      o && o.length > 0 && o[0].id && (chrome.tabs.sendMessage(o[0].id, { type: "SHOW_CONTENT_TOAST", toastType: "error", message: "녹화 처리 중 오류가 발생했습니다" }).catch(function() {
      }), chrome.tabs.sendMessage(o[0].id, { type: "RECORDING_FAILED" }).catch(function() {
      }));
    }).catch(function() {
    });
  }
}
async function _() {
  await chrome.offscreen.hasDocument() || await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["BLOBS"], justification: "WASM processing for video timestamp reset" });
}
chrome.runtime.onMessage.addListener(function(n, d, o) {
  if (n.type === "START_LIVE_RECORDING") return (async function() {
    const t = await (async function() {
      try {
        const l = await navigator.storage.estimate(), h = l.quota - l.usage;
        return { available: h, quota: l.quota, enoughSpace: h >= 5368709120 };
      } catch (l) {
        return console.error("Failed to estimate storage:", l), { available: 0, quota: 0, enoughSpace: !0 };
      }
    })();
    if (t.available, !t.enoughSpace) {
      const l = I(t.available), h = I(t.quota);
      try {
        await chrome.runtime.sendMessage({ type: "STORAGE_WARNING", available: l, quota: h });
      } catch {
      }
      try {
        const T = await chrome.tabs.query({ active: !0 });
        T && T.length > 0 && T[0].id && await chrome.tabs.sendMessage(T[0].id, { type: "SHOW_CONTENT_TOAST", toastType: "warning", message: "저장 공간 부족: " + l + " (권장: 5GB 이상)" });
      } catch {
      }
    }
    I(t.available);
    const a = await chrome.tabs.query({ active: !0, currentWindow: !0 }), r = a && a[0] ? a[0].id : null, i = /* @__PURE__ */ new Date(), p = i.getFullYear(), f = String(i.getMonth() + 1).padStart(2, "0"), S = String(i.getDate()).padStart(2, "0"), s = String(i.getHours()).padStart(2, "0"), c = String(i.getMinutes()).padStart(2, "0"), m = String(i.getSeconds()).padStart(2, "0"), w = `${p}-${f}-${S}_${s}-${c}-${m}`, g = "live_" + Date.now();
    e.channelId = g, e.active = !0, e.initSegmentProcessed = !1, e.tabId = r, e.liveChannelId = w, e.lastSegmentTime = Date.now(), e.recordingStartTime = Date.now(), e.partNumber = 1, R();
    const b = await navigator.storage.getDirectory(), u = await b.getDirectoryHandle("recordings", { create: !0 }), y = `recording_${g}.mp4`;
    e.opfsFileName = y, e.opfsFileHandle = await u.getFileHandle(y, { create: !0 }), e.opfsWritable = await e.opfsFileHandle.createWritable(), await _(), await chrome.runtime.sendMessage({ type: "INIT_FMP4_PROCESSOR" }), await chrome.storage.local.set({ isRecording: !0 });
  })().then(function() {
    o({ success: !0 });
  }).catch(function(t) {
    console.error("Failed to start recording:", t), o({ success: !1, error: t.message });
  }), !0;
  if (n.type === "SET_INIT_SEGMENT") return (async function(t) {
    if (e.active)
      try {
        const a = await fetch(t), r = await a.arrayBuffer();
        e.initSegmentData || (e.initSegmentData = r), e.initSegmentProcessed || (await e.opfsWritable.write(r), e.initSegmentProcessed = !0), await chrome.runtime.sendMessage({ type: "SET_FMP4_INIT_SEGMENT", data: Array.from(new Uint8Array(r)) }), r.byteLength;
      } catch (a) {
        throw console.error("Init segment error:", a), a;
      }
  })(n.url).then(function() {
    o({ success: !0 });
  }).catch(function(t) {
    console.error("Failed to handle init segment:", t), o({ success: !1, error: t.message });
  }), !0;
  if (n.type === "ADD_RECORDING_SEGMENT") return (async function(t) {
    if (!(!e.active || !e.initSegmentProcessed || !e.opfsWritable))
      try {
        const a = await fetch(t), r = await a.arrayBuffer();
        if (!e.opfsWritable || !e.active) return;
        const i = await chrome.runtime.sendMessage({ type: "PROCESS_FMP4_SEGMENT", data: Array.from(new Uint8Array(r)) });
        if (!e.opfsWritable || !e.active) return;
        i.error ? (i.error, await e.opfsWritable.write(r)) : await e.opfsWritable.write(new Uint8Array(i.data)), e.lastSegmentTime = Date.now(), R(), (Date.now() - e.recordingStartTime) / 6e4 >= e.segmentDuration && (e.partNumber, await v(!0), await (async function() {
          try {
            e.partNumber, e.partNumber += 1, e.recordingStartTime = Date.now();
            const p = e.channelId || "live_" + Date.now(), f = await navigator.storage.getDirectory(), S = await f.getDirectoryHandle("recordings", { create: !0 }), s = `recording_${p}_part${e.partNumber}.mp4`, c = await S.getFileHandle(s, { create: !0 }), m = await c.createWritable();
            e.opfsWritable = m, e.opfsFileHandle = c, e.opfsFileName = s, e.active = !0, e.initSegmentData ? (await m.write(e.initSegmentData), e.initSegmentProcessed = !0, e.partNumber) : e.initSegmentProcessed = !1;
          } catch (p) {
            console.error("Failed to start next recording part:", p), e.active = !1;
          }
        })()), r.byteLength;
      } catch (a) {
        if (!a.message || !a.message.includes("CLOSED")) throw console.error("Media segment error:", a), a;
      }
  })(n.url).then(function() {
    o({ success: !0 });
  }).catch(function(t) {
    console.error("Failed to handle media segment:", t), o({ success: !1, error: t.message });
  }), !0;
  if (n.type === "STOP_LIVE_RECORDING") v(), o({ success: !0 });
  else if (n.type === "HLS_SEGMENT_DETECTED") {
    const t = n.url, a = t.match(/(.*\/)([^/]+)\.ts(\?.*)?$/);
    if (a) {
      const r = a[1];
      if (!D.has(r)) {
        const i = { firstSegmentUrl: t, baseUrl: r, timestamp: Date.now(), downloaded: !1, thumbnailData: null };
        D.set(r, i), chrome.runtime.sendMessage({ type: "NEW_CLIP_DETECTED", clip: i }).catch(function() {
        });
      }
    }
    o({ success: !0 });
  } else if (n.type === "GET_DETECTED_CLIPS") o({ clips: Array.from(D.values()) });
  else {
    if (n.type === "DOWNLOAD_CLIP") return (async function(t, a, r) {
      const i = t.match(/(.*\/)([^/]+)\.ts(\?.*)?$/);
      if (!i) throw new Error("Invalid URL");
      const p = i[1], f = i[2], S = i[3] || "", s = f.match(/-(\d+)$/);
      let c;
      if (/^[a-f0-9\-]+-\d+$/.test(f) && s) {
        const h = f.substring(0, f.lastIndexOf("-")), T = s[1].length;
        c = function(O) {
          return p + h + "-" + String(O).padStart(T, "0") + ".ts" + S;
        };
      } else c = function(h) {
        return p + h + ".ts" + S;
      };
      const m = [];
      let w = 0, g = 0;
      for (; g < 3; ) try {
        const h = await fetch(c(w));
        if (!h.ok) {
          g++, w++;
          continue;
        }
        const T = await h.blob();
        m.push(T), g = 0, r && r({ stage: "downloading", current: m.length, index: w }), w++;
      } catch {
        g++, w++;
      }
      if (m.length === 0) throw new Error("No chunks");
      const b = new Blob(m, { type: "video/mp2t" });
      if (a) return { segmentCount: m.length, totalSize: b.size, blobUrl: URL.createObjectURL(b) };
      const u = "chzzk-clip-" + (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-").slice(0, -5) + ".ts", y = await b.arrayBuffer(), l = await N(y);
      return chrome.downloads.download({ url: "data:video/mp2t;base64," + l, filename: "chzzk-clips/" + u, saveAs: !0 }), { segmentCount: m.length, totalSize: b.size };
    })(n.url, n.returnData, function(t) {
      chrome.runtime.sendMessage({ type: "DOWNLOAD_PROGRESS", progress: t }).catch(function() {
      });
    }).then(function(t) {
      o({ success: !0, ...t });
    }).catch(function(t) {
      o({ success: !1, error: t.message });
    }), !0;
    if (n.type === "CLEAR_CLIPS") D.clear(), o({ success: !0 });
    else if (n.type === "REMOVE_CLIP") D.delete(n.baseUrl), o({ success: !0 });
    else if (n.type === "SAVE_THUMBNAIL") {
      const t = D.get(n.baseUrl);
      t && (t.thumbnailData = n.thumbnailData, D.set(n.baseUrl, t)), o({ success: !0 });
    } else if (n.type === "UPDATE_CLIP_STATUS") {
      const t = D.get(n.baseUrl);
      t && (n.downloaded !== void 0 && (t.downloaded = n.downloaded), n.failed !== void 0 && (t.failed = n.failed), D.set(n.baseUrl, t)), o({ success: !0 });
    } else if (n.type === "SHOW_TOAST") chrome.runtime.sendMessage({ type: "DISPLAY_TOAST", toastType: n.toastType, message: n.message }).catch(function() {
    }), o({ success: !0 });
    else {
      if (n.type === "RECOVER_RECORDING") return (async function(t) {
        try {
          const a = await navigator.storage.getDirectory(), r = await a.getDirectoryHandle("recordings", { create: !1 }), i = await r.getFileHandle(t), p = await i.getFile(), f = await p.arrayBuffer(), S = await N(f), s = `chzzk-recovered-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-").slice(0, -10)}.mp4`;
          await chrome.downloads.download({ url: `data:video/mp4;base64,${S}`, filename: `chzzk-recordings/${s}`, saveAs: !0 });
          const { hiddenRecordings: c = [] } = await chrome.storage.local.get("hiddenRecordings");
          return c.includes(t) || (c.push(t), await chrome.storage.local.set({ hiddenRecordings: c })), !0;
        } catch (a) {
          throw console.error("Recovery failed:", a), a;
        }
      })(n.filename).then(function() {
        o({ success: !0 });
      }).catch(function(t) {
        console.error("Failed to recover recording:", t), o({ success: !1, error: t.message });
      }), !0;
      if (n.type === "DELETE_ORPHANED_RECORDING") return (async function(t) {
        try {
          const { hiddenRecordings: a = [] } = await chrome.storage.local.get("hiddenRecordings");
          return a.includes(t) || (a.push(t), await chrome.storage.local.set({ hiddenRecordings: a })), !0;
        } catch (a) {
          throw console.error("Delete failed:", a), a;
        }
      })(n.filename).then(function() {
        o({ success: !0 });
      }).catch(function(t) {
        console.error("Failed to delete recording:", t), o({ success: !1, error: t.message });
      }), !0;
      if (n.type === "PAGE_UNLOADING_DURING_RECORDING") e.active && v(), o({ success: !0 });
      else if (n.type === "CLEAR_ALL_TEMP_FILES") return (async function() {
        try {
          let t = 0, a = 0;
          try {
            const r = await navigator.storage.getDirectory(), i = await r.getDirectoryHandle("recordings", { create: !1 }), p = [];
            for await (const f of i.values()) f.kind === "file" && p.push(f.name);
            for (const f of p) try {
              await i.removeEntry(f), t++;
            } catch {
            }
          } catch {
          }
          try {
            await _();
            const r = await chrome.runtime.sendMessage({ type: "CLEANUP_INDEXEDDB", keepKeys: [] });
            r.success ? a = r.deletedCount || 0 : console.error("IndexedDB cleanup failed:", r.error);
          } catch {
          }
          return await chrome.storage.local.remove("hiddenRecordings"), { success: !0, opfsDeleted: t, indexedDBDeleted: a };
        } catch (t) {
          return console.error("clearAllTemporaryFiles failed:", t), { success: !1, error: t.message };
        }
      })().then(function(t) {
        o(t);
      }).catch(function(t) {
        console.error("Failed to clear temp files:", t), o({ success: !1, error: t.message });
      }), !0;
    }
  }
  return !0;
});
