import{l as s,a}from"../chunks/p5voW804.js";export{s as load_css,a as start};
