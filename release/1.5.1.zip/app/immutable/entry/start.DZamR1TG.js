import{l as s,a}from"../chunks/BQO4Y3ML.js";export{s as load_css,a as start};
